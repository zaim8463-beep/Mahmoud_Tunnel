# Third-party notices

## sing-box Android libbox

Mahmoud Tunnel 0.9.9 declares a dependency on the Android binding distributed by
[`singbox-android/libbox`](https://github.com/singbox-android/libbox), version 1.14.4,
resolved from JitPack as `com.github.singbox-android:libbox:1.14.4`.

The upstream repository provides its source under the GNU General Public License,
version 3 (GPL-3.0). See the upstream [`LICENSE`](https://github.com/singbox-android/libbox/blob/main/LICENSE)
and review the exact license and corresponding-source obligations before distributing
a binary that includes this dependency. This project now contains a libbox adapter and Android VPN service integration. The source-level adapter has not yet been compiled or verified on a device, and no live VPN server deployment is included.

The Android `TunnelVpnService` in 0.9.31 hosts the pinned libbox engine. Review the GPL-3.0 license and corresponding-source requirements before distributing this combined application.
