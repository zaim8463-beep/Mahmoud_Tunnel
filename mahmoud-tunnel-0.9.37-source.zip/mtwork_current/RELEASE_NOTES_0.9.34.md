# Mahmoud Tunnel 0.9.34

- Added a direct paste/import flow for supported VPN share links (including VLESS, Trojan, Shadowsocks, VMess, SOCKS, and HTTP profiles supported by the existing parser/converter).
- Updated the displayed preview version and subscription User-Agent.
- The server setup kit now uses the official signed sing-box APT repository, installs prerequisites, and validates the installed configuration.

## Verification status

- Source changes inspected and ZIP integrity checked.
- Android APK build and device-level tunnel traffic are still unverified because this environment has no Android SDK or Gradle installation and no authorized VPS/server to test against.
