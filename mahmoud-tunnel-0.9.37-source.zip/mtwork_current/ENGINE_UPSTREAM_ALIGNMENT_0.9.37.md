# Upstream Android integration notes — 0.9.37

The Android VPN lifecycle was compared with the public `SagerNet/sing-box-for-android` implementation.

## Findings applied

- `VpnService.Builder.establish()` returns a `ParcelFileDescriptor`. The upstream service keeps that descriptor as a service field and returns `pfd.fd` from `PlatformInterface.openTun()`. Mahmoud Tunnel now follows the same ownership rule and closes the descriptor during orderly engine shutdown.
- The upstream platform adapter subscribes to default-interface changes and forwards updates through `InterfaceUpdateListener.updateDefaultInterface(name, index, false, false)`. Mahmoud Tunnel now registers an Android `ConnectivityManager.NetworkCallback`, forwards the current interface name/index, and unregisters it during teardown.
- The command-server sequence remains: `Libbox.setup`, `Libbox.checkConfig`, `CommandServer.start`, then `startOrReloadService`.

## Public upstream references

- https://github.com/SagerNet/sing-box-for-android/blob/dev/app/src/main/java/io/nekohasekai/sfa/bg/VPNService.kt
- https://github.com/SagerNet/sing-box-for-android/blob/dev/app/src/main/java/io/nekohasekai/sfa/bg/BoxService.kt
- https://github.com/SagerNet/sing-box-for-android/blob/dev/app/src/main/java/io/nekohasekai/sfa/bg/DefaultNetworkMonitor.kt

## Remaining verification

This source-level alignment does not prove a successful APK build or live VPN connection. The current environment has no installed Gradle or Android SDK and cannot resolve external download hosts. The next engineering gate is Android compilation, followed by emulator/device testing with a server profile the user is authorized to use.
