package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileExportNameTest {
    @Test public void choosesNativeExtensionsForTunnelFiles() {
        assertEquals("Office.ovpn", ProfileExportName.create("Office", "OpenVPN"));
        assertEquals("Home.conf", ProfileExportName.create("Home", "WireGuard"));
        assertEquals("Germany.txt", ProfileExportName.create("Germany", "VLESS"));
    }

    @Test public void removesPathAndControlCharacters() {
        assertEquals("_secret.conf", ProfileExportName.create("../secret", "WireGuard"));
        assertEquals("My_Profile.txt", ProfileExportName.create("My  Profile", "VLESS"));
    }

    @Test public void handlesMissingAndVeryLongNames() {
        assertEquals("profile.txt", ProfileExportName.create("  ", "Unknown"));
        assertTrue(ProfileExportName.create(repeat('a', 100), "OpenVPN").length() <= 53);
    }

    private static String repeat(char value, int count) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) result.append(value);
        return result.toString();
    }
}
