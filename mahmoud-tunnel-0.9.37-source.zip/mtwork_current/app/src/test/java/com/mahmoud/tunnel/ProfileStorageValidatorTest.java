package com.mahmoud.tunnel;

import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import static org.junit.Assert.*;

public class ProfileStorageValidatorTest {
    private static final String VLESS = "vless://id@vpn.example:443";

    private static String repeat(String value, int count) {
        StringBuilder out = new StringBuilder(value.length() * count);
        for (int i = 0; i < count; i++) out.append(value);
        return out.toString();
    }

    @Test public void acceptsRecognizedBoundedRecord() {
        assertTrue(ProfileStorageValidator.isValidRecord("Europe node", "VLESS", VLESS));
    }

    @Test public void rejectsMalformedShareLinksWhenRestoringStorage() {
        assertFalse(ProfileStorageValidator.isValidRecord("Node", "VLESS", "vless://missing-host"));
        assertFalse(ProfileStorageValidator.isValidRecord("Node", "Trojan", "trojan://@vpn.example:443"));
    }

    @Test public void acceptsValidAlternateShareLinkWhenRestoringStorage() {
        assertTrue(ProfileStorageValidator.isValidRecord("Node", "Hysteria2", "hy2://secret@vpn.example:443"));
        assertTrue(ProfileStorageValidator.isValidRecord("Node", "WireGuard", "wg://private@vpn.example:51820"));
    }

    @Test public void rejectsUnknownProtocolAndProtocolMismatch() {
        assertFalse(ProfileStorageValidator.isValidRecord("Node", "Unknown", VLESS));
        assertFalse(ProfileStorageValidator.isValidRecord("Node", "Trojan", VLESS));
    }

    @Test public void rejectsUnsafeNamesAndOversizedValues() {
        assertFalse(ProfileStorageValidator.isValidRecord("bad\nname", "VLESS", VLESS));
        assertFalse(ProfileStorageValidator.isValidRecord(repeat("x", 43), "VLESS", VLESS));
        assertFalse(ProfileStorageValidator.isValidRecord("Node", "VLESS", repeat("x", 256 * 1024 + 1)));
    }

    @Test public void validatesWholeBatchAndRejectsDuplicates() {
        assertTrue(ProfileStorageValidator.isValidBatch(Arrays.asList(
                new ProfileStorageValidator.Record("One", "VLESS", VLESS),
                new ProfileStorageValidator.Record("Two", "Trojan", "trojan://secret@vpn2.example:443"))));
        assertFalse(ProfileStorageValidator.isValidBatch(Arrays.asList(
                new ProfileStorageValidator.Record("One", "VLESS", VLESS),
                new ProfileStorageValidator.Record("Duplicate", "VLESS", VLESS))));
        assertFalse(ProfileStorageValidator.isValidBatch(Collections.emptyList()));
    }

    @Test public void rejectsTooManyRecords() {
        java.util.ArrayList<ProfileStorageValidator.Record> records = new java.util.ArrayList<>();
        for (int i = 0; i < 101; i++) {
            records.add(new ProfileStorageValidator.Record("Node " + i, "VLESS", "vless://id" + i + "@vpn.example:443"));
        }
        assertFalse(ProfileStorageValidator.isValidBatch(records));
    }
}
