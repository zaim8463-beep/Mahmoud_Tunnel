package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class VpnEngineCoordinatorTest {
    private static final class FakeEngine implements VpnEngine {
        StartCallback start;
        StopCallback stop;
        @Override public void start(Profile profile, StartCallback callback) { start = callback; }
        @Override public void stop(StopCallback callback) { stop = callback; }
    }

    @Test public void onlyBackendCallbackCanMarkConnected() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, null);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        assertEquals(ConnectionStateMachine.State.PREPARING, coordinator.getState());
        engine.start.onConnected();
        assertEquals(ConnectionStateMachine.State.CONNECTED, coordinator.getState());
    }

    @Test public void disconnectReturnsToIdleOnlyAfterBackendStops() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, null);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        engine.start.onConnected();
        coordinator.disconnect();
        assertEquals(ConnectionStateMachine.State.STOPPING, coordinator.getState());
        engine.stop.onStopped();
        assertEquals(ConnectionStateMachine.State.IDLE, coordinator.getState());
    }

    @Test public void startFailureDoesNotReportConnected() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, null);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        engine.start.onFailure(new RuntimeException("native engine failed"));
        assertEquals(ConnectionStateMachine.State.FAILED, coordinator.getState());
    }

    @Test public void staleConnectCallbackCannotOverrideLaterState() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, null);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        VpnEngine.StartCallback stale = engine.start;
        stale.onFailure(new RuntimeException("failed"));
        coordinator.connect(new VpnEngine.Profile("test2", "VLESS", "vless://id@example.com:443"));
        stale.onConnected();
        assertEquals(ConnectionStateMachine.State.PREPARING, coordinator.getState());
    }

    @Test public void listenerRunsWithoutHoldingCoordinatorMonitor() throws Exception {
        FakeEngine engine = new FakeEngine();
        final VpnEngineCoordinator[] holder = new VpnEngineCoordinator[1];
        final java.util.concurrent.atomic.AtomicBoolean inspected = new java.util.concurrent.atomic.AtomicBoolean(false);
        VpnEngineCoordinator.Listener listener = new VpnEngineCoordinator.Listener() {
            @Override public void onStateChanged(ConnectionStateMachine.State state) {
                Thread inspector = new Thread(() -> {
                    holder[0].getState();
                    inspected.set(true);
                });
                inspector.start();
                try { inspector.join(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
            @Override public void onError(Throwable cause) { }
        };
        holder[0] = new VpnEngineCoordinator(engine, listener);
        holder[0].connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        assertTrue("listener must not hold the coordinator monitor", inspected.get());
    }


    @Test public void throwingStateListenerCannotBlockEngineStart() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator.Listener listener = new VpnEngineCoordinator.Listener() {
            @Override public void onStateChanged(ConnectionStateMachine.State state) {
                throw new IllegalStateException("broken UI observer");
            }
            @Override public void onError(Throwable cause) { }
        };
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, listener);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        assertNotNull("engine start must still be invoked", engine.start);
        assertEquals(ConnectionStateMachine.State.PREPARING, coordinator.getState());
        engine.start.onConnected();
        assertEquals(ConnectionStateMachine.State.CONNECTED, coordinator.getState());
    }

    @Test public void throwingErrorListenerCannotCorruptFailureState() {
        FakeEngine engine = new FakeEngine();
        VpnEngineCoordinator.Listener listener = new VpnEngineCoordinator.Listener() {
            @Override public void onStateChanged(ConnectionStateMachine.State state) { }
            @Override public void onError(Throwable cause) {
                throw new IllegalStateException("broken error UI");
            }
        };
        VpnEngineCoordinator coordinator = new VpnEngineCoordinator(engine, listener);
        coordinator.connect(new VpnEngine.Profile("test", "VLESS", "vless://id@example.com:443"));
        engine.start.onFailure(new RuntimeException("engine failure"));
        assertEquals(ConnectionStateMachine.State.FAILED, coordinator.getState());
    }

    @Test public void missingEngineIsRejected() {
        try {
            new VpnEngineCoordinator(null, null);
            fail("Expected missing engine rejection");
        } catch (IllegalArgumentException expected) { }
    }
}
