package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileLinkValidatorTest {
    @Test public void acceptsStructurallyValidLinks() {
        assertTrue(ProfileLinkValidator.isValidShareLink("VLESS", "vless://id@vpn.example:443"));
        assertTrue(ProfileLinkValidator.isValidShareLink("Trojan", "trojan://secret@vpn.example:443"));
        assertTrue(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJhZGQiOiJ2cG4uZXhhbXBsZSIsInBvcnQiOiI0NDMiLCJpZCI6ImFiY2QtMTIzNCJ9"));
        assertTrue(ProfileLinkValidator.isValidShareLink("Hysteria2", "hy2://secret@vpn.example:443"));
        assertTrue(ProfileLinkValidator.isValidShareLink("WireGuard", "wg://private@vpn.example:51820"));
        assertTrue(ProfileLinkValidator.isValidShareLink("SOCKS", "socks5://vpn.example:1080"));
    }

    @Test public void rejectsMissingAuthorityCredentialsOrValidPort() {
        assertFalse(ProfileLinkValidator.isValidShareLink("VLESS", "vless://id@vpn.example"));
        assertFalse(ProfileLinkValidator.isValidShareLink("VLESS", "vless://@vpn.example:443"));
        assertFalse(ProfileLinkValidator.isValidShareLink("Trojan", "trojan://secret@vpn.example:70000"));
        assertFalse(ProfileLinkValidator.isValidShareLink("SSH", "ssh://vpn.example:22"));
        assertFalse(ProfileLinkValidator.isValidShareLink("VLESS", "vless://id@/443"));
    }

    @Test public void rejectsMalformedOrIncompleteVmessPayloads() {
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://not-base64!"));
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJ2IjoiMiJ9"));
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJhZGQiOiJ2cG4uZXhhbXBsZSIsInBvcnQiOiI3MDAwMCIsImlkIjoiYWJjZCJ9"));
    }

    @Test public void vmessRequiresRequiredFieldsAtJsonRoot() {
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJtZXRhIjp7ImFkZCI6InZwbi5leGFtcGxlIiwicG9ydCI6IjQ0MyIsImlkIjoiYWJjZC0xMjM0In19"));
    }

    @Test public void vmessRejectsTrailingGarbageAndAcceptsNumericPort() {
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJhZGQiOiJ2cG4uZXhhbXBsZSIsInBvcnQiOiI0NDMiLCJpZCI6ImFiY2QtMTIzNCJ9IHRyYWlsaW5n"));
        assertTrue(ProfileLinkValidator.isValidShareLink("VMess", "vmess://eyJhZGQiOiJ2cG4uZXhhbXBsZSIsInBvcnQiOjQ0MywiaWQiOiJhYmNkLTEyMzQifQ=="));
    }

    @Test public void vmessRejectsUrlLikeOrMalformedAddressValues() {
        assertFalse(validVmessWith("https://vpn.example"));
        assertFalse(validVmessWith("vpn.example/path"));
        assertFalse(validVmessWith("vpn..example"));
        assertFalse(validVmessWith("vpn.example?next=evil"));
    }

    @Test public void vmessRejectsDuplicateKeysInsideNestedObjects() {
        String json = "{\"add\":\"vpn.example\",\"port\":443,\"id\":\"abcd-1234\",\"meta\":{\"mode\":1,\"mode\":2}}";
        String payload = java.util.Base64.getEncoder().withoutPadding()
                .encodeToString(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://" + payload));
    }

    private static boolean validVmessWith(String address) {
        String json = "{\"add\":\"" + address + "\",\"port\":443,\"id\":\"abcd-1234\"}";
        String payload = java.util.Base64.getEncoder().withoutPadding()
                .encodeToString(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return ProfileLinkValidator.isValidShareLink("VMess", "vmess://" + payload);
    }

    @Test public void vmessRejectsDuplicateRootKeys() {
        String json = "{\"add\":\"vpn.example\",\"add\":\"evil.example\",\"port\":443,\"id\":\"abcd-1234\"}";
        String payload = java.util.Base64.getEncoder().withoutPadding()
                .encodeToString(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://" + payload));
    }

    @Test public void vmessRejectsExcessiveJsonNestingWithoutCrashing() {
        StringBuilder json = new StringBuilder();
        for (int i = 0; i < 80; i++) json.append("{\"x\":");
        json.append("0");
        for (int i = 0; i < 80; i++) json.append('}');
        String payload = java.util.Base64.getEncoder().withoutPadding()
                .encodeToString(json.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        assertFalse(ProfileLinkValidator.isValidShareLink("VMess", "vmess://" + payload));
    }


    @Test public void aliasSchemesApplyTheSameInputSizeLimit() {
        String oversizedWg = "wg://host.example:51820/" + new String(new char[65537]).replace('\0', 'a');
        String oversizedHy2 = "hy2://secret@host.example:443/" + new String(new char[65537]).replace('\0', 'a');
        assertFalse(ProfileLinkValidator.isValidShareLink("WireGuard", oversizedWg));
        assertFalse(ProfileLinkValidator.isValidShareLink("Hysteria2", oversizedHy2));
        assertFalse(ProfileLinkValidator.isValidShareLink("SOCKS", "   "));
    }

    @Test public void acceptsSupportedHttpProxySchemesAndRejectsInvalidPorts() {
        assertTrue(ProfileLinkValidator.isValidShareLink("HTTP Proxy", "http://proxy.example:8080"));
        assertTrue(ProfileLinkValidator.isValidShareLink("HTTP Proxy", "https://proxy.example:443"));
        assertFalse(ProfileLinkValidator.isValidShareLink("HTTP Proxy", "http://proxy.example:0"));
        assertFalse(ProfileLinkValidator.isValidShareLink("HTTP Proxy", "http://proxy.example:65536"));
    }

    @Test public void rejectsUnknownProtocolAndNulls() {
        assertFalse(ProfileLinkValidator.isValidShareLink("Unknown", "vless://id@vpn.example:443"));
        assertFalse(ProfileLinkValidator.isValidShareLink("VLESS", null));
        assertFalse(ProfileLinkValidator.isValidShareLink(null, "vless://id@vpn.example:443"));
    }
}
