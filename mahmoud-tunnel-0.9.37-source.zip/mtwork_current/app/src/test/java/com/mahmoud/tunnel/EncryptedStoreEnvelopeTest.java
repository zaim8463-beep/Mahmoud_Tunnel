package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class EncryptedStoreEnvelopeTest {
    @Test public void acceptsOnlyBoundedEncodedLengths() {
        assertTrue(EncryptedStoreEnvelope.isAcceptableEncodedLength(24));
        assertTrue(EncryptedStoreEnvelope.isAcceptableEncodedLength(EncryptedStoreEnvelope.MAX_BASE64_CHARS));
        assertFalse(EncryptedStoreEnvelope.isAcceptableEncodedLength(0));
        assertFalse(EncryptedStoreEnvelope.isAcceptableEncodedLength(EncryptedStoreEnvelope.MAX_BASE64_CHARS + 1));
    }

    @Test public void validatesGcmEnvelopeNonceAndTagBounds() {
        byte[] valid = new byte[1 + 12 + 16 + 1];
        valid[0] = 12;
        assertTrue(EncryptedStoreEnvelope.isValidPacked(valid));
        assertFalse(EncryptedStoreEnvelope.isValidPacked(null));
        assertFalse(EncryptedStoreEnvelope.isValidPacked(new byte[28]));
        byte[] wrongNonce = valid.clone();
        wrongNonce[0] = 16;
        assertFalse(EncryptedStoreEnvelope.isValidPacked(wrongNonce));
        byte[] noCiphertext = new byte[1 + 12 + 16];
        noCiphertext[0] = 12;
        assertFalse(EncryptedStoreEnvelope.isValidPacked(noCiphertext));
    }
}
