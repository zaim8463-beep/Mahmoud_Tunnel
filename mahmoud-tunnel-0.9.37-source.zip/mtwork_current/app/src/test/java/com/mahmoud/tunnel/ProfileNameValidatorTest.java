package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileNameValidatorTest {
    @Test public void trimsAndRemovesPathSeparatorsAndControls() {
        assertEquals("Europe Server", ProfileNameValidator.normalize("  Europe/\nServer  "));
    }
    @Test public void limitsNamesToFortyTwoCharacters() {
        assertEquals(42, ProfileNameValidator.normalize("123456789012345678901234567890123456789012345").length());
    }
    @Test public void rejectsEmptyOrControlOnlyNames() {
        assertFalse(ProfileNameValidator.isValid("  \n\t "));
        assertFalse(ProfileNameValidator.isValid(null));
        assertTrue(ProfileNameValidator.isValid("My VPN"));
    }
}
