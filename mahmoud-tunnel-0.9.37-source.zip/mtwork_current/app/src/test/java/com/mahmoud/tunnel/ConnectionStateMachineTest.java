package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ConnectionStateMachineTest {
    @Test public void supportsSuccessfulConnectAndDisconnectLifecycle() {
        ConnectionStateMachine machine = new ConnectionStateMachine();
        assertEquals(ConnectionStateMachine.State.IDLE, machine.getState());
        machine.transition(ConnectionStateMachine.State.PREPARING);
        machine.transition(ConnectionStateMachine.State.CONNECTED);
        machine.transition(ConnectionStateMachine.State.STOPPING);
        machine.transition(ConnectionStateMachine.State.IDLE);
        assertEquals(ConnectionStateMachine.State.IDLE, machine.getState());
    }

    @Test public void supportsFailureRecovery() {
        ConnectionStateMachine machine = new ConnectionStateMachine();
        machine.transition(ConnectionStateMachine.State.PREPARING);
        machine.transition(ConnectionStateMachine.State.FAILED);
        machine.transition(ConnectionStateMachine.State.IDLE);
        machine.transition(ConnectionStateMachine.State.PREPARING);
        assertEquals(ConnectionStateMachine.State.PREPARING, machine.getState());
    }

    @Test(expected = IllegalStateException.class)
    public void refusesConnectedWithoutPreparation() {
        new ConnectionStateMachine().transition(ConnectionStateMachine.State.CONNECTED);
    }

    @Test(expected = IllegalStateException.class)
    public void refusesStopBeforeConnected() {
        ConnectionStateMachine machine = new ConnectionStateMachine();
        machine.transition(ConnectionStateMachine.State.PREPARING);
        machine.transition(ConnectionStateMachine.State.STOPPING);
    }

    @Test(expected = IllegalArgumentException.class)
    public void refusesNullState() {
        new ConnectionStateMachine().transition(null);
    }
}
