package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class ProfileProtocolDetectorTest {
    @Test public void recognizesShareLinkSchemes() {
        assertEquals("VLESS", ProfileProtocolDetector.detect("vless://id@example.test:443"));
        assertEquals("VMess", ProfileProtocolDetector.detect("vmess://eyJ2IjoiMiJ9"));
        assertEquals("Trojan", ProfileProtocolDetector.detect("trojan://secret@example.test:443"));
        assertEquals("WireGuard", ProfileProtocolDetector.detect("wg://private-key@example.test:51820"));
        assertEquals("WireGuard", ProfileProtocolDetector.detect("# managed profile\n[Interface]\nPrivateKey = private\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = public\nEndpoint = vpn.example.test:51820\n"));
        assertEquals("OpenVPN", ProfileProtocolDetector.detect("client\ndev tun\nproto udp\nremote vpn.example.test 1194\n"));
        assertEquals("SSH", ProfileProtocolDetector.detect("ssh://user@example.test:22"));
        assertEquals("Shadowsocks", ProfileProtocolDetector.detect("ss://YWVzLTI1Ni1nY206cGFzcw==@example.test:8388"));
        assertEquals("Hysteria2", ProfileProtocolDetector.detect("hy2://secret@example.test:443"));
        assertEquals("Hysteria", ProfileProtocolDetector.detect("hysteria://secret@example.test:443"));
        assertEquals("TUIC", ProfileProtocolDetector.detect("tuic://uuid:password@example.test:443"));
        assertEquals("AnyTLS", ProfileProtocolDetector.detect("anytls://secret@example.test:443"));
        assertEquals("ShadowTLS", ProfileProtocolDetector.detect("shadowtls://secret@example.test:443"));
        assertEquals("SOCKS", ProfileProtocolDetector.detect("socks5://example.test:1080"));
        assertEquals("SOCKS", ProfileProtocolDetector.detect("socks4://example.test:1080"));
        assertEquals("SOCKS", ProfileProtocolDetector.detect("socks5h://example.test:1080"));
        assertEquals("HTTP Proxy", ProfileProtocolDetector.detect("http://user:pass@example.test:8080"));
        assertEquals("HTTP Proxy", ProfileProtocolDetector.detect("https://user:pass@example.test:8443/"));
    }

    @Test public void trimsAndMatchesSchemesCaseInsensitively() {
        assertEquals("VLESS", ProfileProtocolDetector.detect("  VLESS://id@example.test:443  "));
        assertEquals("HTTP Proxy", ProfileProtocolDetector.detect("HTTP://user:pass@example.test:3128"));
    }

    @Test public void recognizesBomAndClassicMacLineEndings() {
        assertEquals("WireGuard", ProfileProtocolDetector.detect("\uFEFF[Interface]\rPrivateKey = private\r[Peer]\rPublicKey = public\rEndpoint = vpn.example.test:51820"));
        assertEquals("OpenVPN", ProfileProtocolDetector.detect("client\rdev tun\rremote vpn.example.test 1194"));
    }

    @Test public void rejectsUnknownAndEmptyValues() {
        assertEquals("Unknown", ProfileProtocolDetector.detect(""));
        assertEquals("Unknown", ProfileProtocolDetector.detect("https://example.test/subscription"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("https://example.test:443/subscription"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("http://example.test:8080/website"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("http://example.test:8080"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("not-a-config"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("client\nremote vpn.example.test 1194\n"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("[Interface]\nPrivateKey = private\n[Peer]\nPublicKey = public\n"));
        assertEquals("Unknown", ProfileProtocolDetector.detect("dev tun\nremote vpn.example.test 1194\n"));
        assertEquals("Unknown", ProfileProtocolDetector.detect(null));
    }
}
