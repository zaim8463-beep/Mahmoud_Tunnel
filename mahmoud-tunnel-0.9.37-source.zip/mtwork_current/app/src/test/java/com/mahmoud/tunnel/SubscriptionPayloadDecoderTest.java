package com.mahmoud.tunnel;

import org.junit.Test;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.*;

public class SubscriptionPayloadDecoderTest {
    @Test public void decodesUtf8AndRemovesBom() throws Exception {
        byte[] bytes = ("\uFEFF  vless://example\n").getBytes(StandardCharsets.UTF_8);
        assertEquals("vless://example", SubscriptionPayloadDecoder.decodeUtf8(bytes, 1024));
    }
    @Test public void rejectsMalformedUtf8() {
        try { SubscriptionPayloadDecoder.decodeUtf8(new byte[] {(byte)0xC3, (byte)0x28}, 1024); fail("Malformed UTF-8 accepted"); }
        catch (CharacterCodingException expected) { }
    }
    @Test public void rejectsOversizedBodyBeforeDecoding() {
        try { SubscriptionPayloadDecoder.decodeUtf8(new byte[5], 4); fail("Oversized payload accepted"); }
        catch (IllegalArgumentException expected) { }
    }
    @Test public void rejectsNullBody() {
        try { SubscriptionPayloadDecoder.decodeUtf8(null, 10); fail("Null payload accepted"); }
        catch (IllegalArgumentException expected) { }
    }
}
