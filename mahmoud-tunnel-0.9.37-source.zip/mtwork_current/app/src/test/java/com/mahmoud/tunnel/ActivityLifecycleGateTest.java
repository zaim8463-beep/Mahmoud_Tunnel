package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class ActivityLifecycleGateTest {
    @Test public void startsActive() {
        assertTrue(new ActivityLifecycleGate().isActive());
    }

    @Test public void becomesInactiveAfterDestruction() {
        ActivityLifecycleGate gate = new ActivityLifecycleGate();
        gate.markDestroyed();
        assertFalse(gate.isActive());
    }

    @Test public void destructionIsIdempotent() {
        ActivityLifecycleGate gate = new ActivityLifecycleGate();
        gate.markDestroyed();
        gate.markDestroyed();
        assertFalse(gate.isActive());
    }
}
