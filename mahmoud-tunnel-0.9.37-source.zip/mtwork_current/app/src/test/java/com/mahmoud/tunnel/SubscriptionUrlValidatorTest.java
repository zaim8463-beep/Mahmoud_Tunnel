package com.mahmoud.tunnel;

import org.junit.Test;
import static org.junit.Assert.*;

public class SubscriptionUrlValidatorTest {
    @Test public void acceptsHttpsProviderUrls() {
        assertTrue(SubscriptionUrlValidator.isValidHttpsUrl("https://provider.example/subscription"));
        assertTrue(SubscriptionUrlValidator.isValidHttpsUrl("HTTPS://provider.example:8443/sub?token=a%2Fb"));
    }

    @Test public void rejectsNonHttpsAndMalformedUrls() {
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("http://provider.example/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("ftp://provider.example/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https:///missing-host"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://provider.example:70000/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://provider.example:0/sub"));
    }

    @Test public void rejectsLocalAndPrivateNetworkTargets() {
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://localhost/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://router.local/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://service.internal/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://127.0.0.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://10.0.0.8/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://127.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://2130706433/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://0177.0.0.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://0x7f.0.0.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://192.0.2.10/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://198.51.100.10/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://203.0.113.10/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://192.168.1.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://169.254.169.254/latest/meta-data"));
        assertTrue(SubscriptionUrlValidator.isValidHttpsUrl("https://8.8.8.8/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://[fc00::1]/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://[2001:db8::1]/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://[2002:0808:0808::1]/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://[3fff::1]/sub"));
        assertTrue(SubscriptionUrlValidator.isValidHttpsUrl("https://[2606:4700:4700::1111]/sub"));
    }

    @Test public void rejectsNonCanonicalNumericHostSpellings() {
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://127.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://2130706433/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://0x7f000001/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://0177.0.0.1/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://192.0.2.10/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://198.51.100.7/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://203.0.113.9/sub"));
        assertTrue(SubscriptionUrlValidator.isValidHttpsUrl("https://8.8.8.8/sub"));
    }

    @Test public void rejectsEmbeddedCredentialsFragmentsAndWhitespace() {
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://user:pass@provider.example/sub"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://provider.example/sub#fragment"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("https://provider.example/sub path"));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl("  "));
        assertFalse(SubscriptionUrlValidator.isValidHttpsUrl(null));
    }
}
