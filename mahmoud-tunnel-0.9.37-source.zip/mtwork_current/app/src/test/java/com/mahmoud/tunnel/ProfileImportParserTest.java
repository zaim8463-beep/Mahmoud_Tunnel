package com.mahmoud.tunnel;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class ProfileImportParserTest {
    @Test public void keepsMultilineWireGuardProfileWhole() {
        String wg = "# sample\n[Interface]\nPrivateKey = private\nAddress = 10.0.0.2/32\n\n[Peer]\nPublicKey = public\nEndpoint = vpn.example.test:51820";
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(wg);
        assertEquals(1, entries.size());
        assertEquals("WireGuard", entries.get(0).protocol);
        assertEquals(wg, entries.get(0).value);
    }

    @Test public void keepsMultilineOpenVpnProfileWhole() {
        String ovpn = "client\ndev tun\nproto udp\nremote vpn.example.test 1194\n<ca>\nCERTIFICATE\n</ca>";
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(ovpn);
        assertEquals(1, entries.size());
        assertEquals("OpenVPN", entries.get(0).protocol);
        assertEquals(ovpn, entries.get(0).value);
    }

    @Test public void extractsShareLinksAroundMultilineProfile() {
        String wg = "[Interface]\nPrivateKey = private\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = public\nEndpoint = vpn.example.test:51820";
        String subscription = "vless://id@one.example.test:443\n" + wg + "\ntrojan://secret@two.example.test:443";
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(subscription);
        assertEquals(3, entries.size());
        assertEquals("VLESS", entries.get(0).protocol);
        assertEquals("WireGuard", entries.get(1).protocol);
        assertEquals(wg, entries.get(1).value);
        assertEquals("Trojan", entries.get(2).protocol);
    }


    @Test public void handlesUtf8BomAndClassicMacLineEndings() {
        String wg = "\uFEFF[Interface]\rPrivateKey = private\rAddress = 10.0.0.2/32\r[Peer]\rPublicKey = public\rEndpoint = vpn.example.test:51820";
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(wg);
        assertEquals(1, entries.size());
        assertEquals("WireGuard", entries.get(0).protocol);
        assertTrue(entries.get(0).value.startsWith("[Interface]"));
        assertTrue(entries.get(0).value.contains("\n"));
    }

    @Test public void extractsLinksFromClassicMacLineEndings() {
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(
                "vless://id@one.example.test:443\rtrojan://secret@two.example.test:443");
        assertEquals(2, entries.size());
        assertEquals("VLESS", entries.get(0).protocol);
        assertEquals("Trojan", entries.get(1).protocol);
    }

    @Test public void ignoresUnsupportedTextAndNull() {
        assertTrue(ProfileImportParser.parse("not a profile\njust text").isEmpty());
        assertTrue(ProfileImportParser.parse(null).isEmpty());
    }

    @Test public void rejectsMalformedShareLinksInsteadOfSavingThem() {
        assertTrue(ProfileImportParser.parse("vless://missing-host").isEmpty());
        assertTrue(ProfileImportParser.parse("trojan://@vpn.example.test:443").isEmpty());
        assertTrue(ProfileImportParser.parse("vless://id@vpn.example.test:99999").isEmpty());
    }

    @Test public void keepsValidLinksWhenMalformedLinesAreMixedIn() {
        List<ProfileImportParser.Entry> entries = ProfileImportParser.parse(
                "vless://id@one.example.test:443\n" +
                "trojan://missing-host\n" +
                "trojan://secret@two.example.test:443");
        assertEquals(2, entries.size());
        assertEquals("VLESS", entries.get(0).protocol);
        assertEquals("Trojan", entries.get(1).protocol);
    }

}
