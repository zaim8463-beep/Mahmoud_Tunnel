package com.mahmoud.tunnel;

/** Normalizes user-visible profile names without changing the underlying config. */
public final class ProfileNameValidator {
    public static final int MAX_LENGTH = 42;
    private ProfileNameValidator() { }

    public static String normalize(String raw) {
        if (raw == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c == '/' || c == '\\') out.append(' ');
            else if (!Character.isISOControl(c)) out.append(c);
        }
        String value = out.toString().trim().replaceAll("\\s+", " ");
        if (value.length() > MAX_LENGTH) value = value.substring(0, MAX_LENGTH).trim();
        return value;
    }

    public static boolean isValid(String raw) {
        String value = normalize(raw);
        return !value.isEmpty() && value.length() <= MAX_LENGTH;
    }
}
