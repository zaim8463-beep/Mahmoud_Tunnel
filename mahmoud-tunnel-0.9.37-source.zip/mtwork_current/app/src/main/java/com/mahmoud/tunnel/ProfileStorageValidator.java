package com.mahmoud.tunnel;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Fail-closed validation for profile records restored from local storage. */
public final class ProfileStorageValidator {
    public static final int MAX_PROFILES = 100;
    public static final int MAX_PROFILE_CHARS = 256 * 1024;
    public static final int MAX_TOTAL_CHARS = 2 * 1024 * 1024;

    private ProfileStorageValidator() { }

    public static boolean isValidRecord(String name, String protocol, String value) {
        if (name == null || protocol == null || value == null) return false;
        if (name.trim().isEmpty() || name.length() > 42 || hasControlCharacters(name)) return false;
        if (!isSupportedProtocol(protocol)) return false;
        String normalizedValue = value.trim();
        if (normalizedValue.isEmpty() || value.length() > MAX_PROFILE_CHARS) return false;
        if (!protocol.equals(ProfileProtocolDetector.detect(value))) return false;
        // Restored share links must pass the same structural checks as newly imported links.
        // Multiline WireGuard/OpenVPN files and JSON outbounds continue through their own paths.
        if (startsWithShareLinkScheme(normalizedValue)) {
            return ProfileLinkValidator.isValidShareLink(protocol, normalizedValue);
        }
        return true;
    }

    /** Validates count, aggregate size, record structure, and duplicate contents as one batch. */
    public static boolean isValidBatch(List<Record> records) {
        if (records == null || records.isEmpty() || records.size() > MAX_PROFILES) return false;
        long total = 0;
        Set<String> values = new HashSet<>();
        for (Record record : records) {
            if (record == null || !isValidRecord(record.name, record.protocol, record.value)) return false;
            if (!values.add(record.value)) return false;
            total += record.value.length();
            if (total > MAX_TOTAL_CHARS) return false;
        }
        return true;
    }

    private static boolean startsWithShareLinkScheme(String value) {
        int separator = value.indexOf("://");
        if (separator <= 0 || separator > 24) return false;
        for (int i = 0; i < separator; i++) {
            char c = value.charAt(i);
            boolean valid = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
                    || (i > 0 && ((c >= '0' && c <= '9') || c == '+' || c == '.' || c == '-'));
            if (!valid) return false;
        }
        return true;
    }

    private static boolean hasControlCharacters(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (Character.isISOControl(value.charAt(i))) return true;
        }
        return false;
    }

    private static boolean isSupportedProtocol(String protocol) {
        switch (protocol) {
            case "VLESS": case "VMess": case "Trojan": case "WireGuard":
            case "OpenVPN": case "SSH": case "Shadowsocks": case "Hysteria":
            case "Hysteria2": case "TUIC": case "AnyTLS": case "ShadowTLS":
            case "SOCKS": case "HTTP Proxy":
                return true;
            default:
                return false;
        }
    }

    public static final class Record {
        public final String name;
        public final String protocol;
        public final String value;

        public Record(String name, String protocol, String value) {
            this.name = name;
            this.protocol = protocol;
            this.value = value;
        }
    }
}
