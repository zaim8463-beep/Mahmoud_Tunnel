package com.mahmoud.tunnel;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Strict, bounded UTF-8 decoding for downloaded subscription payloads. */
public final class SubscriptionPayloadDecoder {
    private SubscriptionPayloadDecoder() { }

    public static String decodeUtf8(byte[] bytes, int maxBytes) throws CharacterCodingException {
        if (bytes == null) throw new IllegalArgumentException("Subscription body is missing");
        if (maxBytes < 0 || bytes.length > maxBytes) {
            throw new IllegalArgumentException("Subscription exceeds the configured size limit");
        }
        String decoded = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString();
        if (!decoded.isEmpty() && decoded.charAt(0) == '\uFEFF') {
            decoded = decoded.substring(1);
        }
        return decoded.trim();
    }
}
