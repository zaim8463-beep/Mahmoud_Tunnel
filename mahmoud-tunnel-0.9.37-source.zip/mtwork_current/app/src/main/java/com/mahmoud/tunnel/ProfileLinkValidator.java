package com.mahmoud.tunnel;

import java.net.URI;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.util.HashMap;
import java.util.Map;

/** Conservative structural checks for imported share links; this is not an engine config check. */
public final class ProfileLinkValidator {
    private ProfileLinkValidator() { }

    public static boolean isValid(String protocol, String value) {
        if (protocol == null || value == null) return false;
        String link = value.trim();
        // Bound parser work and prevent oversized clipboard/subscription entries.
        if (link.isEmpty() || link.length() > 65536) return false;
        String expectedScheme = schemeFor(protocol);
        if (expectedScheme == null) return false;
        try {
            URI uri = new URI(link);
            if (uri.getScheme() == null || !expectedScheme.equals(uri.getScheme().toLowerCase(Locale.ROOT))) return false;
            if ("vmess".equals(expectedScheme)) {
                // VMess carries a Base64-encoded JSON server profile, not a normal URI authority.
                return isValidVmessPayload(uri.getRawSchemeSpecificPart());
            }
            if (uri.getHost() == null || uri.getHost().trim().isEmpty()) return false;
            int port = uri.getPort();
            if (port < 1 || port > 65535) return false;
            String userInfo = uri.getRawUserInfo();
            if (requiresUserInfo(expectedScheme) && (userInfo == null || userInfo.isEmpty())) return false;
            if ("vless".equals(expectedScheme) && userInfo != null && userInfo.indexOf(':') >= 0) return false;
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }


    private static boolean isValidVmessPayload(String payload) {
        if (payload != null && payload.startsWith("//")) payload = payload.substring(2);
        if (payload == null || payload.isEmpty() || containsWhitespace(payload)) return false;
        byte[] decoded = decodeBase64(payload);
        if (decoded == null || decoded.length == 0 || decoded.length > 16384) return false;
        final String json;
        try {
            json = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(decoded)).toString();
        } catch (CharacterCodingException ignored) {
            return false;
        }
        Map<String, String> fields = parseTopLevelJsonStringsAndScalars(json);
        if (fields == null) return false;
        String address = fields.get("add");
        String id = fields.get("id");
        String portText = fields.get("port");
        if (!isValidVmessAddress(address)
                || id == null || id.trim().isEmpty() || id.length() > 128 || containsWhitespace(id)
                || portText == null) return false;
        try {
            int port = Integer.parseInt(portText);
            return port >= 1 && port <= 65535;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    /** VMess `add` is a host literal/name, never a URL, authority, or path. */
    private static boolean isValidVmessAddress(String address) {
        if (address == null || address.isEmpty() || address.length() > 253 || containsWhitespace(address)) return false;
        for (int i = 0; i < address.length(); i++) {
            char c = address.charAt(i);
            if (c == '/' || c == '?' || c == '#' || c == '@' || c == '\\' || c == '<' || c == '>') return false;
        }
        return !address.startsWith(".") && !address.contains("..") && !address.endsWith(".");
    }

    /** Parses a JSON object and returns only its direct string/number fields. */
    private static Map<String, String> parseTopLevelJsonStringsAndScalars(String json) {
        if (json == null || json.length() > 16384) return null;
        JsonCursor cursor = new JsonCursor(json);
        Map<String, String> fields = new HashMap<>();
        try {
            cursor.skipWhitespace();
            cursor.expect('{');
            cursor.skipWhitespace();
            if (cursor.take('}')) {
                cursor.skipWhitespace();
                return cursor.atEnd() ? fields : null;
            }
            while (true) {
                cursor.skipWhitespace();
                String key = cursor.readString();
                if (fields.containsKey(key) || cursor.hasSeenKey(key)) return null;
                cursor.rememberKey(key);
                cursor.skipWhitespace();
                cursor.expect(':');
                cursor.skipWhitespace();
                String scalar = cursor.readValue(0);
                if (scalar != null) fields.put(key, scalar);
                cursor.skipWhitespace();
                if (cursor.take('}')) break;
                cursor.expect(',');
            }
            cursor.skipWhitespace();
            return cursor.atEnd() ? fields : null;
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    /** Small strict JSON cursor; nested values are validated but never mistaken for root fields. */
    private static final class JsonCursor {
        private final String text;
        private final java.util.HashSet<String> seenKeys = new java.util.HashSet<>();
        private int pos;
        JsonCursor(String text) { this.text = text; }
        boolean hasSeenKey(String key) { return seenKeys.contains(key); }
        void rememberKey(String key) { seenKeys.add(key); }
        boolean atEnd() { return pos == text.length(); }
        void skipWhitespace() { while (pos < text.length() && (text.charAt(pos) == ' ' || text.charAt(pos) == '\n' || text.charAt(pos) == '\r' || text.charAt(pos) == '\t')) pos++; }
        boolean take(char c) { if (pos < text.length() && text.charAt(pos) == c) { pos++; return true; } return false; }
        void expect(char c) { if (!take(c)) throw new IllegalArgumentException(); }
        String readString() {
            expect('"'); StringBuilder out = new StringBuilder();
            while (pos < text.length()) {
                char c = text.charAt(pos++);
                if (c == '"') return out.toString();
                if (c < 0x20) throw new IllegalArgumentException();
                if (c == '\\') {
                    if (pos >= text.length()) throw new IllegalArgumentException();
                    char e = text.charAt(pos++);
                    switch (e) {
                        case '"': case '\\': case '/': out.append(e); break;
                        case 'b': out.append('\b'); break; case 'f': out.append('\f'); break;
                        case 'n': out.append('\n'); break; case 'r': out.append('\r'); break; case 't': out.append('\t'); break;
                        case 'u':
                            if (pos + 4 > text.length()) throw new IllegalArgumentException();
                            int code = 0;
                            for (int i = 0; i < 4; i++) { int d = Character.digit(text.charAt(pos++), 16); if (d < 0) throw new IllegalArgumentException(); code = (code << 4) | d; }
                            out.append((char) code); break;
                        default: throw new IllegalArgumentException();
                    }
                } else out.append(c);
            }
            throw new IllegalArgumentException();
        }
        String readValue(int depth) {
            // Bound nesting to avoid stack exhaustion from hostile, deeply nested JSON.
            if (depth > 64 || pos >= text.length()) throw new IllegalArgumentException();
            if (text.charAt(pos) == '"') return readString();
            if (take('{')) {
                skipWhitespace(); if (take('}')) return null;
                java.util.HashSet<String> objectKeys = new java.util.HashSet<>();
                while (true) {
                    skipWhitespace();
                    String key = readString();
                    if (!objectKeys.add(key)) throw new IllegalArgumentException();
                    skipWhitespace(); expect(':'); skipWhitespace(); readValue(depth + 1);
                    skipWhitespace(); if (take('}')) break; expect(',');
                }
                return null;
            }
            if (take('[')) {
                skipWhitespace(); if (take(']')) return null;
                while (true) { skipWhitespace(); readValue(depth + 1); skipWhitespace(); if (take(']')) break; expect(','); }
                return null;
            }
            int begin = pos;
            while (pos < text.length() && ",}] \r\n\t".indexOf(text.charAt(pos)) < 0) pos++;
            String token = text.substring(begin, pos);
            if ("true".equals(token) || "false".equals(token) || "null".equals(token)) return null;
            if (!token.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?")) throw new IllegalArgumentException();
            return token;
        }
    }

    private static boolean containsWhitespace(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (Character.isWhitespace(value.charAt(i)) || Character.isISOControl(value.charAt(i))) return true;
        }
        return false;
    }

    /** Small strict Base64 decoder to keep validation compatible with minSdk 24 and plain JVM tests. */
    private static byte[] decodeBase64(String input) {
        String value = input.replace('-', '+').replace('_', '/');
        int firstPadding = value.indexOf('=');
        if (firstPadding >= 0) {
            if (value.length() - firstPadding > 2) return null;
            for (int i = firstPadding; i < value.length(); i++) if (value.charAt(i) != '=') return null;
            if (value.length() % 4 != 0) return null;
            value = value.substring(0, firstPadding);
        }
        if (value.length() % 4 == 1) return null;
        java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
        int buffer = 0, bits = 0;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            int digit;
            if (c >= 'A' && c <= 'Z') digit = c - 'A';
            else if (c >= 'a' && c <= 'z') digit = c - 'a' + 26;
            else if (c >= '0' && c <= '9') digit = c - '0' + 52;
            else if (c == '+') digit = 62;
            else if (c == '/') digit = 63;
            else return null;
            buffer = (buffer << 6) | digit;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                output.write((buffer >> bits) & 0xff);
            }
        }
        if (bits > 0 && (buffer & ((1 << bits) - 1)) != 0) return null;
        return output.toByteArray();
    }

    private static boolean requiresUserInfo(String scheme) {
        switch (scheme) {
            case "vless": case "trojan": case "hysteria": case "hysteria2":
            case "tuic": case "anytls": case "shadowtls": case "ssh":
                return true;
            default:
                return false;
        }
    }

    private static String schemeFor(String protocol) {
        switch (protocol) {
            case "VLESS": return "vless";
            case "VMess": return "vmess";
            case "Trojan": return "trojan";
            case "WireGuard": return "wireguard"; // wireguard:// is handled separately below
            case "SSH": return "ssh";
            case "Shadowsocks": return "ss";
            case "Hysteria": return "hysteria";
            case "Hysteria2": return "hysteria2"; // hy2:// is an accepted alias below
            case "TUIC": return "tuic";
            case "AnyTLS": return "anytls";
            case "ShadowTLS": return "shadowtls";
            case "SOCKS": return "socks";
            default: return null;
        }
    }

    public static boolean isValidShareLink(String protocol, String value) {
        if ("WireGuard".equals(protocol)) {
            return isValidScheme(value, "wireguard") || isValidScheme(value, "wg");
        }
        if ("Hysteria2".equals(protocol)) {
            return isValidScheme(value, "hysteria2") || isValidScheme(value, "hy2");
        }
        if ("SOCKS".equals(protocol)) {
            return isValidScheme(value, "socks") || isValidScheme(value, "socks4")
                    || isValidScheme(value, "socks5") || isValidScheme(value, "socks5h");
        }
        if ("HTTP Proxy".equals(protocol)) {
            return isValidScheme(value, "http") || isValidScheme(value, "https");
        }
        return isValid(protocol, value);
    }

    private static boolean isValidScheme(String value, String scheme) {
        // Apply the same input bound to aliases (wg://, hy2://, socks5://, etc.)
        // as the primary protocol validator before URI parsing allocates parser state.
        if (value == null) return false;
        String link = value.trim();
        if (link.isEmpty() || link.length() > 65536) return false;
        try {
            URI uri = new URI(link);
            if (uri.getScheme() == null || !scheme.equals(uri.getScheme().toLowerCase(Locale.ROOT))) return false;
            if ("vmess".equals(scheme)) {
                return isValidVmessPayload(uri.getRawSchemeSpecificPart());
            }
            if (uri.getHost() == null || uri.getHost().trim().isEmpty()) return false;
            int port = uri.getPort();
            if (port < 1 || port > 65535) return false;
            String info = uri.getRawUserInfo();
            if (requiresUserInfo(scheme) && (info == null || info.isEmpty())) return false;
            if ("vless".equals(scheme) && info != null && info.indexOf(':') >= 0) return false;
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }
}
