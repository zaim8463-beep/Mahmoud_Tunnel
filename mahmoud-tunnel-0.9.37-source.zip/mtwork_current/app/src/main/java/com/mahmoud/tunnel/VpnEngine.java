package com.mahmoud.tunnel;

/**
 * Contract for a real VPN backend (for example, a verified libbox adapter).
 * No production implementation is bundled yet. Implementations must call onConnected
 * only after the Android VPN interface and tunnel are actually established.
 */
public interface VpnEngine {
    final class Profile {
        public final String name;
        public final String protocol;
        public final String content;

        public Profile(String name, String protocol, String content) {
            if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Profile name is required");
            if (protocol == null || protocol.trim().isEmpty()) throw new IllegalArgumentException("Profile protocol is required");
            if (content == null || content.trim().isEmpty()) throw new IllegalArgumentException("Profile content is required");
            this.name = name;
            this.protocol = protocol;
            this.content = content;
        }
    }

    interface StartCallback {
        /** Called only after the tunnel is genuinely established. */
        void onConnected();
        void onFailure(Throwable cause);
    }

    interface StopCallback {
        void onStopped();
        void onFailure(Throwable cause);
    }

    void start(Profile profile, StartCallback callback) throws Exception;
    void stop(StopCallback callback) throws Exception;
}
