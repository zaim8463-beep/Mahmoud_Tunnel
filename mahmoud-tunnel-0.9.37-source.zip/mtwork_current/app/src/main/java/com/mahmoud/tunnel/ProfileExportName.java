package com.mahmoud.tunnel;

import java.util.Locale;

/** Creates a safe suggested filename for a profile exported through Android's document picker. */
public final class ProfileExportName {
    private ProfileExportName() { }

    public static String create(String name, String protocol) {
        String base = name == null ? "profile" : name.trim();
        if (base.isEmpty()) base = "profile";
        base = base.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_")
                .replaceAll("\\s+", "_")
                .replaceAll("_+", "_");
        base = base.replaceAll("^\\.+|\\.+$", "");
        if (base.isEmpty()) base = "profile";
        if (base.length() > 48) base = base.substring(0, 48);

        String extension;
        if ("OpenVPN".equals(protocol)) extension = ".ovpn";
        else if ("WireGuard".equals(protocol)) extension = ".conf";
        else if ("VLESS".equals(protocol) || "VMess".equals(protocol)
                || "Trojan".equals(protocol) || "Shadowsocks".equals(protocol)
                || "Hysteria".equals(protocol) || "Hysteria2".equals(protocol)
                || "TUIC".equals(protocol) || "AnyTLS".equals(protocol)
                || "ShadowTLS".equals(protocol) || "SOCKS".equals(protocol)
                || "HTTP Proxy".equals(protocol) || "SSH".equals(protocol)) extension = ".txt";
        else extension = ".txt";
        return base + extension;
    }
}
