package com.mahmoud.tunnel;

/** Bounds and validates the small binary envelope used by AES-GCM profile storage. */
public final class EncryptedStoreEnvelope {
    // 2 MiB of profile text plus JSON/Base64 metadata; reject pathological preference values early.
    public static final int MAX_BASE64_CHARS = 3 * 1024 * 1024;
    private static final int GCM_NONCE_BYTES = 12;
    private static final int GCM_TAG_BYTES = 16;

    private EncryptedStoreEnvelope() { }

    public static boolean isAcceptableEncodedLength(int length) {
        return length >= 1 && length <= MAX_BASE64_CHARS;
    }

    /** Envelope layout: one nonce-length byte, 12-byte nonce, then ciphertext plus 16-byte tag. */
    public static boolean isValidPacked(byte[] packed) {
        if (packed == null || packed.length < 1 + GCM_NONCE_BYTES + GCM_TAG_BYTES) return false;
        int nonceLength = packed[0] & 0xff;
        return nonceLength == GCM_NONCE_BYTES && packed.length > 1 + nonceLength + GCM_TAG_BYTES;
    }
}
