package com.mahmoud.tunnel;

import android.app.Activity;
import android.net.VpnService;
import android.os.Build;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

/** UI, encrypted profile manager, and VPN permission/start workflow. */
public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 41;
    private static final int CREATE_EXPORT = 42;
    private static final int REQUEST_VPN_PERMISSION = 43;
    private static final String KEY_ALIAS = "mahmoud_tunnel_profiles_v1";
    private static final String ENCRYPTED_PREFIX = "enc1:";
    private static final int MAX_PROFILE_CHARS = 256 * 1024;
    private static final int MAX_STORE_CHARS = 2 * 1024 * 1024;
    private static final int MAX_SUBSCRIPTION_BYTES = 1024 * 1024;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private static final int BG = Color.rgb(13, 21, 35);
    private static final int PANEL = Color.rgb(25, 39, 58);
    private static final int MUTED = Color.rgb(159, 177, 198);
    private final ArrayList<Profile> profiles = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout profileList;
    private TextView status;
    private Button connectButton;
    private Button disconnectButton;
    private String pendingVpnConfig;
    private boolean vpnReceiverRegistered;
    private boolean vpnActiveOrStarting;
    private final BroadcastReceiver vpnStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TunnelVpnService.ACTION_STATE.equals(intent.getAction())) return;
            String state = intent.getStringExtra(TunnelVpnService.EXTRA_STATE);
            String error = intent.getStringExtra(TunnelVpnService.EXTRA_ERROR);
            if ("STARTING".equals(state)) {
                vpnActiveOrStarting = true;
                status.setText("STARTING VPN ENGINE…"); status.setTextColor(Color.rgb(245, 190, 95));
                if (connectButton != null) connectButton.setEnabled(false);
                if (disconnectButton != null) disconnectButton.setEnabled(true);
            } else if ("CONNECTED".equals(state)) {
                vpnActiveOrStarting = true;
                status.setText("VPN CONNECTED"); status.setTextColor(Color.rgb(80, 210, 160));
                if (connectButton != null) connectButton.setEnabled(false);
                if (disconnectButton != null) disconnectButton.setEnabled(true);
            } else if ("FAILED".equals(state)) {
                vpnActiveOrStarting = false;
                status.setText("VPN CONNECTION FAILED"); status.setTextColor(Color.rgb(245, 120, 110));
                if (connectButton != null) connectButton.setEnabled(selected != null && !vpnActiveOrStarting);
                if (disconnectButton != null) disconnectButton.setEnabled(false);
                Toast.makeText(MainActivity.this, error == null ? "VPN failed to start" : error, Toast.LENGTH_LONG).show();
            } else if ("DISCONNECTED".equals(state)) {
                vpnActiveOrStarting = false;
                status.setText("VPN DISCONNECTED"); status.setTextColor(Color.rgb(245, 190, 95));
                if (connectButton != null) connectButton.setEnabled(selected != null && !vpnActiveOrStarting);
                if (disconnectButton != null) disconnectButton.setEnabled(false);
            }
        }
    };
    private TextView profileCount;
    private EditText searchBox;
    private String searchQuery = "";
    private Profile selected;
    private Profile pendingExport;
    private final ActivityLifecycleGate lifecycleGate = new ActivityLifecycleGate();

    private static class Profile {
        String name, protocol, value;
        Profile(String n, String p, String v) { name=n; protocol=p; value=v; }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private Button button(String value) {
        Button b = new Button(this); b.setText(value); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(17, 137, 129)));
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("profiles", MODE_PRIVATE);
        loadProfiles();
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(28)); root.setBackgroundColor(BG);
        scroll.addView(root);

        TextView brand = label("MAHMOUD TUNNEL", 25, Color.WHITE, true); brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView sub = label("Import profiles • Secure sing-box VPN", 13, MUTED, false); sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        addSpace(root, 22);

        status = label(statusMessage == null ? (selected == null ? "IMPORT A PROFILE TO BEGIN" : "READY TO CONNECT") : statusMessage, 13, Color.rgb(245, 190, 95), true); status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(34)));
        TextView warning = label("Import a supported profile from a provider you trust, select it below, then connect. A valid reachable server is required.", 13, MUTED, false);
        warning.setGravity(Gravity.CENTER); warning.setPadding(dp(8), dp(8), dp(8), dp(14)); root.addView(warning);

        Button importButton = button("＋  Import configuration");
        root.addView(importButton, new LinearLayout.LayoutParams(-1, dp(54)));
        importButton.setOnClickListener(v -> openPicker());
        Button pasteButton = button("⌁  Paste share link");
        LinearLayout.LayoutParams pasteParams = new LinearLayout.LayoutParams(-1, dp(50));
        pasteParams.topMargin = dp(8);
        root.addView(pasteButton, pasteParams);
        pasteButton.setOnClickListener(v -> promptShareLink());
        Button subscriptionButton = button("↧  Import subscription URL");
        LinearLayout.LayoutParams subscriptionParams = new LinearLayout.LayoutParams(-1, dp(50));
        subscriptionParams.topMargin = dp(8);
        root.addView(subscriptionButton, subscriptionParams);
        subscriptionButton.setOnClickListener(v -> promptSubscriptionUrl());
        connectButton = button("Connect selected profile");
        LinearLayout.LayoutParams connectParams = new LinearLayout.LayoutParams(-1, dp(54));
        connectParams.topMargin = dp(10);
        root.addView(connectButton, connectParams);
        connectButton.setOnClickListener(v -> connectSelectedProfile());
        disconnectButton = button("Disconnect VPN");
        LinearLayout.LayoutParams disconnectParams = new LinearLayout.LayoutParams(-1, dp(48));
        disconnectParams.topMargin = dp(7);
        root.addView(disconnectButton, disconnectParams);
        disconnectButton.setEnabled(false);
        disconnectButton.setOnClickListener(v -> disconnectVpn());
        addSpace(root, 22);
        TextView heading = label("MY CONFIGURATIONS", 12, MUTED, true); root.addView(heading);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setHintTextColor(MUTED);
        searchBox.setHint("Search by name or protocol");
        searchBox.setPadding(dp(14), dp(8), dp(14), dp(8));
        searchBox.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(75, 105, 130)));
        root.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(48)));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s == null ? "" : s.toString().trim().toLowerCase();
                renderProfiles();
            }
            @Override public void afterTextChanged(Editable e) { }
        });
        profileCount = label("0 profiles", 12, MUTED, false);
        LinearLayout.LayoutParams countParams = new LinearLayout.LayoutParams(-1, dp(28));
        countParams.topMargin = dp(8);
        root.addView(profileCount, countParams);
        profileList = new LinearLayout(this); profileList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, -2); listParams.topMargin = dp(10);
        root.addView(profileList, listParams); renderProfiles();

        addSpace(root, 24);
        TextView footer = label("Mahmoud Tunnel  •  Preview 0.9.35\nOnly import profiles from providers you trust and are authorized to use.", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER); root.addView(footer);
        setContentView(scroll);
        IntentFilter vpnFilter = new IntentFilter(TunnelVpnService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(vpnStateReceiver, vpnFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(vpnStateReceiver, vpnFilter);
        vpnReceiverRegistered = true;
        if (connectButton != null) connectButton.setEnabled(selected != null && !vpnActiveOrStarting);
        if (disconnectButton != null) disconnectButton.setEnabled(false);
    }

    @Override protected void onDestroy() {
        // The subscription worker must not outlive its Activity.
        lifecycleGate.markDestroyed();
        if (vpnReceiverRegistered) { try { unregisterReceiver(vpnStateReceiver); } catch (Exception ignored) { } vpnReceiverRegistered = false; }
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    private void connectSelectedProfile() {
        if (selected == null) {
            Toast.makeText(this, "Select a configuration first", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            pendingVpnConfig = SingBoxConfigBuilder.build(selected.protocol, selected.value, selected.name);
            Intent permission = VpnService.prepare(this);
            if (permission != null) startActivityForResult(permission, REQUEST_VPN_PERMISSION);
            else startVpnService();
        } catch (Exception e) {
            Toast.makeText(this, "This profile cannot start: " + (e.getMessage() == null ? "invalid profile" : e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void disconnectVpn() {
        startService(new Intent(this, TunnelVpnService.class).setAction(TunnelVpnService.ACTION_STOP));
        status.setText("DISCONNECTING VPN…");
        status.setTextColor(Color.rgb(245, 190, 95));
        if (disconnectButton != null) disconnectButton.setEnabled(false);
    }

    private void startVpnService() {
        if (pendingVpnConfig == null) return;
        Intent intent = new Intent(this, TunnelVpnService.class)
                .setAction(TunnelVpnService.ACTION_START)
                .putExtra(TunnelVpnService.EXTRA_CONFIG, pendingVpnConfig);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        pendingVpnConfig = null;
        vpnActiveOrStarting = true;
        status.setText("STARTING VPN ENGINE…");
        status.setTextColor(Color.rgb(245, 190, 95));
        if (connectButton != null) connectButton.setEnabled(false);
        Toast.makeText(this, "Starting secure VPN tunnel…", Toast.LENGTH_SHORT).show();
    }

    private void addSpace(LinearLayout root, int height) {
        View space = new View(this); root.addView(space, new LinearLayout.LayoutParams(1, dp(height)));
    }


    private void promptSubscriptionUrl() {
        EditText urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setHint("https://provider.example/subscription");
        new AlertDialog.Builder(this)
                .setTitle("Import subscription")
                .setMessage("Use an HTTPS subscription link from a provider you trust.")
                .setView(urlInput)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Import", (dialog, which) -> fetchSubscription(urlInput.getText().toString().trim()))
                .show();
    }

    private void fetchSubscription(String address) {
        if (!SubscriptionUrlValidator.isValidHttpsUrl(address)) {
            Toast.makeText(this, "Use a valid HTTPS URL without embedded credentials or fragments", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Downloading subscription…", Toast.LENGTH_SHORT).show();
        networkExecutor.execute(() -> {
            HttpsURLConnection connection = null;
            try {
                connection = (HttpsURLConnection) new URL(address).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setInstanceFollowRedirects(false);
                connection.setRequestProperty("Accept", "text/plain, application/json, */*");
                connection.setRequestProperty("User-Agent", "MahmoudTunnel/0.9.35");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("Provider returned HTTP " + code + ". Redirects are not followed for security.");
                int declaredLength = connection.getContentLength();
                if (declaredLength > MAX_SUBSCRIPTION_BYTES) throw new Exception("Subscription exceeds the 1 MB limit");
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                try (InputStream input = connection.getInputStream()) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        if (output.size() + count > MAX_SUBSCRIPTION_BYTES) throw new Exception("Subscription exceeds the 1 MB limit");
                        output.write(buffer, 0, count);
                    }
                }
                String body = SubscriptionPayloadDecoder.decodeUtf8(output.toByteArray(), MAX_SUBSCRIPTION_BYTES);
                if (body.isEmpty()) throw new Exception("Subscription is empty");
                if (!looksLikeProfileText(body)) {
                    try {
                        byte[] decoded = Base64.decode(body, Base64.DEFAULT | Base64.URL_SAFE);
                        String candidate = new String(decoded, StandardCharsets.UTF_8).trim();
                        if (looksLikeProfileText(candidate)) body = candidate;
                    } catch (IllegalArgumentException ignored) { }
                }
                final String content = body;
                runOnUiThread(() -> {
                    if (!lifecycleGate.isActive() || isFinishing()) return;
                    try {
                        importContent(content, "Subscription profile");
                    } catch (Exception e) {
                        Toast.makeText(this, "Subscription import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "Network error" : e.getMessage();
                runOnUiThread(() -> {
                    if (!lifecycleGate.isActive() || isFinishing()) return;
                    Toast.makeText(this, "Subscription download failed: " + message, Toast.LENGTH_LONG).show();
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private boolean looksLikeProfileText(String content) {
        String value = content == null ? "" : content.trim();
        return value.startsWith("{") || value.startsWith("[") || value.contains("://") || value.startsWith("[Interface]");
    }


    private void promptShareLink() {
        EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setMaxLines(5);
        input.setHint("vless://…  or  trojan://…  or  ss://…");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(MUTED);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        new AlertDialog.Builder(this)
                .setTitle("Paste VPN share link")
                .setMessage("Paste a configuration link from a provider you trust and are authorized to use.")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Import", (dialog, which) -> {
                    try {
                        importContent(input.getText() == null ? "" : input.getText().toString(), "Pasted profile");
                    } catch (Exception e) {
                        Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/json", "application/octet-stream"});
        startActivityForResult(i, PICK_CONFIG);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VPN_PERMISSION) {
            if (resultCode == RESULT_OK) startVpnService();
            else {
                pendingVpnConfig = null;
                vpnActiveOrStarting = false;
                if (connectButton != null) connectButton.setEnabled(selected != null);
                Toast.makeText(this, "VPN permission is required to connect", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode == CREATE_EXPORT) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null || pendingExport == null) {
                pendingExport = null;
                return;
            }
            exportProfile(data.getData(), pendingExport);
            pendingExport = null;
            return;
        }
        if (requestCode != PICK_CONFIG || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Cannot open file");
            // Enforce the import limit while reading, not after allocating the whole file.
            // This prevents a maliciously large document from exhausting app memory.
            StringBuilder content = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                if (content.length() + read > 1024 * 1024) {
                    throw new Exception("File is larger than 1 MB");
                }
                content.append(buffer, 0, read);
            }
            importContent(content.toString(), uri.getLastPathSegment());
        } catch (Exception e) {
            Toast.makeText(this, "Could not read configuration: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void importContent(String raw, String fallbackName) throws Exception {
        if (raw == null || raw.trim().isEmpty()) throw new Exception("The selected file is empty");
        if (raw.length() > 1024 * 1024) throw new Exception("File is larger than 1 MB");

        // Build a temporary batch first. Nothing is added to the live list unless
        // every profile passes validation and both storage limits are satisfied.
        ArrayList<Profile> pending = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Profile existing : profiles) seen.add(existing.value);
        String value = raw.trim();
        if (value.length() > MAX_PROFILE_CHARS && (value.startsWith("{") || value.startsWith("["))) {
            throw new Exception("A single profile cannot exceed 256 KB");
        }

        if ((value.startsWith("{") || value.startsWith("[")) && detectProtocol(value).equals("Unknown")) {
            throw new Exception("JSON file is not a recognized sing-box profile");
        }
        for (ProfileImportParser.Entry entry : ProfileImportParser.parse(value)) {
            String candidate = entry.value;
            String protocol = entry.protocol;
            if (candidate.length() > MAX_PROFILE_CHARS) throw new Exception("A single profile cannot exceed 256 KB");
            if (!seen.add(candidate)) continue;
            String name = safeProfileName(fallbackName, protocol);
            if (pending.size() > 0) name = protocol + " " + (pending.size() + 1);
            pending.add(new Profile(name, protocol, candidate));
            if (profiles.size() + pending.size() > 100) throw new Exception("Profile limit reached (100)");
        }

        if (pending.isEmpty()) throw new Exception("No new supported configurations were found");
        if (profiles.size() + pending.size() > 100) throw new Exception("Profile limit reached (100)");
        long totalChars = 0;
        for (Profile profile : profiles) totalChars += profile.value.length();
        for (Profile profile : pending) totalChars += profile.value.length();
        if (totalChars > MAX_STORE_CHARS) throw new Exception("Saved profiles exceed the 2 MB storage limit; remove some profiles first");

        Profile previousSelection = selected;
        profiles.addAll(pending);
        selected = pending.get(pending.size() - 1);
        if (!saveProfiles()) {
            profiles.removeAll(pending);
            selected = previousSelection;
            throw new Exception("Could not securely save imported profiles");
        }
        renderProfiles();
        Toast.makeText(this, pending.size() + " configuration(s) imported", Toast.LENGTH_SHORT).show();
    }

    private String safeProfileName(String rawName, String protocol) {
        String name = rawName == null || rawName.trim().isEmpty() ? protocol + " profile" : rawName.trim();
        if (name.contains("/")) name = name.substring(name.lastIndexOf('/') + 1);
        StringBuilder clean = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (!Character.isISOControl(c)) clean.append(c);
        }
        name = clean.toString().trim();
        if (name.isEmpty()) name = protocol + " profile";
        if (name.length() > 42) name = name.substring(name.length() - 42);
        return name;
    }


    private String detectProtocol(String value) {
        return ProfileProtocolDetector.detect(value);
    }

    private void loadProfiles() {
        try {
            String stored = prefs.getString("items", "[]");
            if (stored == null) stored = "[]";
            if (stored.startsWith(ENCRYPTED_PREFIX)
                    && !EncryptedStoreEnvelope.isAcceptableEncodedLength(stored.length() - ENCRYPTED_PREFIX.length())) {
                throw new Exception("Encrypted profile store exceeds the safety limit");
            }
            String json;
            if (stored.startsWith(ENCRYPTED_PREFIX)) {
                json = decrypt(stored.substring(ENCRYPTED_PREFIX.length()));
            } else {
                // One-time migration of profiles saved by versions before encrypted storage.
                json = stored;
            }
            JSONArray a = new JSONArray(json);
            if (a.length() > ProfileStorageValidator.MAX_PROFILES) throw new Exception("Too many saved profiles");
            ArrayList<ProfileStorageValidator.Record> records = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                records.add(new ProfileStorageValidator.Record(
                        o.getString("name"), o.getString("protocol"), o.getString("value")));
            }
            if (!records.isEmpty() && !ProfileStorageValidator.isValidBatch(records)) {
                throw new Exception("Saved profile data failed integrity checks");
            }
            for (ProfileStorageValidator.Record record : records) {
                profiles.add(new Profile(record.name, record.protocol, record.value));
            }
            if (!stored.startsWith(ENCRYPTED_PREFIX) && !profiles.isEmpty() && !saveProfiles()) {
                statusMessage = "SECURE PROFILE STORAGE UNAVAILABLE";
            }
            if (!profiles.isEmpty()) selected = profiles.get(0);
        } catch (Exception e) {
            // Do not overwrite encrypted data if the Android Keystore is temporarily unavailable.
            statusMessage = "SECURE PROFILE STORAGE UNAVAILABLE";
            profiles.clear();
        }
    }

    private String statusMessage = null;

    private SecretKey getStorageKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec = new android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS, android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private String encrypt(String plaintext) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getStorageKey());
        byte[] encrypted = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        byte[] iv = cipher.getIV();
        byte[] packed = new byte[1 + iv.length + encrypted.length];
        packed[0] = (byte) iv.length;
        System.arraycopy(iv, 0, packed, 1, iv.length);
        System.arraycopy(encrypted, 0, packed, 1 + iv.length, encrypted.length);
        return Base64.encodeToString(packed, Base64.NO_WRAP);
    }

    private String decrypt(String encoded) throws Exception {
        if (!EncryptedStoreEnvelope.isAcceptableEncodedLength(encoded == null ? 0 : encoded.length())) {
            throw new Exception("Encrypted profile store exceeds the safety limit");
        }
        byte[] packed = Base64.decode(encoded, Base64.NO_WRAP);
        if (!EncryptedStoreEnvelope.isValidPacked(packed)) throw new Exception("Invalid encrypted profile store");
        int ivLength = packed[0] & 0xff;
        byte[] iv = new byte[ivLength];
        byte[] ciphertext = new byte[packed.length - 1 - ivLength];
        System.arraycopy(packed, 1, iv, 0, ivLength);
        System.arraycopy(packed, 1 + ivLength, ciphertext, 0, ciphertext.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getStorageKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
    }

    private boolean saveProfiles() {
        JSONArray a = new JSONArray();
        try {
            for (Profile p : profiles) {
                JSONObject o=new JSONObject(); o.put("name",p.name); o.put("protocol",p.protocol); o.put("value",p.value); a.put(o);
            }
            return prefs.edit().putString("items", ENCRYPTED_PREFIX + encrypt(a.toString())).commit();
        } catch (Exception e) {
            Toast.makeText(this, "Could not securely save profiles", Toast.LENGTH_LONG).show();
            return false;
        }
    }


    private void beginExport(Profile profile) {
        if (profile == null) return;
        pendingExport = profile;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, ProfileExportName.create(profile.name, profile.protocol));
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            startActivityForResult(intent, CREATE_EXPORT);
        } catch (Exception e) {
            pendingExport = null;
            Toast.makeText(this, "File export is unavailable on this device", Toast.LENGTH_LONG).show();
        }
    }

    private void exportProfile(Uri destination, Profile profile) {
        try (java.io.OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
            if (output == null) throw new Exception("Cannot open destination file");
            output.write(profile.value.getBytes(StandardCharsets.UTF_8));
            output.flush();
            Toast.makeText(this, "Profile exported successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            String message = e.getMessage() == null ? "Unknown file error" : e.getMessage();
            Toast.makeText(this, "Export failed: " + message, Toast.LENGTH_LONG).show();
        }
    }

    private void showProfileDetails(Profile profile) {
        if (profile == null) return;
        String message = "Protocol: " + profile.protocol
                + "\nConfiguration size: " + profile.value.length() + " characters"
                + "\n\nCredentials and server details are kept hidden in this summary.";
        new AlertDialog.Builder(this).setTitle(profile.name).setMessage(message)
                .setPositiveButton("Close", null).show();
    }

    private void promptRenameProfile(Profile profile) {
        if (profile == null) return;
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setText(profile.name);
        nameInput.setSelection(nameInput.getText().length());
        new AlertDialog.Builder(this).setTitle("Rename configuration")
                .setMessage("Choose a name up to 42 characters.")
                .setView(nameInput).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newName = ProfileNameValidator.normalize(nameInput.getText().toString());
                    if (!ProfileNameValidator.isValid(newName)) {
                        Toast.makeText(this, "Enter a valid configuration name", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String oldName = profile.name;
                    profile.name = newName;
                    if (!saveProfiles()) {
                        profile.name = oldName;
                        Toast.makeText(this, "Rename was not saved", Toast.LENGTH_LONG).show();
                    }
                    renderProfiles();
                }).show();
    }

    private void confirmRemoveProfile(Profile profile) {
        if (profile == null) return;
        new AlertDialog.Builder(this).setTitle("Remove configuration?")
                .setMessage("\"" + profile.name + "\" will be removed from this device.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (dialog, which) -> removeProfile(profile)).show();
    }

    private void removeProfile(Profile profile) {
        int oldIndex = profiles.indexOf(profile);
        if (oldIndex < 0) return;
        Profile oldSelection = selected;
        profiles.remove(profile);
        if (selected == profile) selected = profiles.isEmpty() ? null : profiles.get(0);
        if (!saveProfiles()) {
            profiles.add(Math.max(0, Math.min(oldIndex, profiles.size())), profile);
            selected = oldSelection;
            Toast.makeText(this, "Delete was not saved; profile restored", Toast.LENGTH_LONG).show();
        }
        renderProfiles();
    }

    private void renderProfiles() {
        if (profileList == null) return;
        if (connectButton != null) connectButton.setEnabled(selected != null && !vpnActiveOrStarting);
        profileList.removeAllViews();
        if (profileCount != null) profileCount.setText(profiles.size() + (profiles.size() == 1 ? " profile" : " profiles"));
        if (profiles.isEmpty()) {
            TextView empty = label("No configurations yet\nImport a profile file or supported link to get started.", 14, MUTED, false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(dp(14), dp(24), dp(14), dp(24)); empty.setBackgroundColor(PANEL);
            profileList.addView(empty); return;
        }
        if (profileCount != null) profileCount.setText(profiles.size() + (profiles.size() == 1 ? " profile" : " profiles"));
        int visibleCount = 0;
        for (Profile p : profiles) {
            String haystack = (p.name + " " + p.protocol).toLowerCase();
            if (!searchQuery.isEmpty() && !haystack.contains(searchQuery)) continue;
            visibleCount++;
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(15), dp(12), dp(15), dp(8)); card.setBackgroundColor(PANEL);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(9); profileList.addView(card, cp);
            TextView name = label((p == selected ? "●  " : "○  ") + p.name, 15, Color.WHITE, true); card.addView(name);
            TextView type = label(p.protocol + "  •  Imported profile", 12, MUTED, false); card.addView(type);
            LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.END); card.addView(actions);
            Button choose = button("Select"); choose.setTextSize(12); actions.addView(choose);
            choose.setOnClickListener(v -> { selected = p; renderProfiles(); });
            Button details = new Button(this); details.setText("Details"); details.setTextSize(12); details.setAllCaps(false); actions.addView(details);
            details.setOnClickListener(v -> showProfileDetails(p));
            Button rename = new Button(this); rename.setText("Rename"); rename.setTextSize(12); rename.setAllCaps(false); actions.addView(rename);
            rename.setOnClickListener(v -> promptRenameProfile(p));
            Button export = new Button(this); export.setText("Export"); export.setTextSize(12); export.setAllCaps(false); actions.addView(export);
            export.setOnClickListener(v -> beginExport(p));
            Button remove = new Button(this); remove.setText("Remove"); remove.setTextSize(12); remove.setAllCaps(false); actions.addView(remove);
            remove.setOnClickListener(v -> confirmRemoveProfile(p));
        }
        if (visibleCount == 0) {
            TextView empty = label(searchQuery.isEmpty() ? "No configurations yet\nImport a profile file or supported link to get started." : "No profiles match your search.", 14, MUTED, false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(dp(14), dp(24), dp(14), dp(24)); empty.setBackgroundColor(PANEL);
            profileList.addView(empty);
        }
    }
}
