package com.mahmoud.tunnel;

/**
 * Coordinates an injected VPN engine with the lifecycle state machine.
 * It deliberately has no fake/default engine: callers must supply a real backend.
 */
public final class VpnEngineCoordinator {
    public interface Listener {
        void onStateChanged(ConnectionStateMachine.State state);
        void onError(Throwable cause);
    }

    private final VpnEngine engine;
    private final ConnectionStateMachine lifecycle = new ConnectionStateMachine();
    private final Listener listener;
    private long operationId;

    public VpnEngineCoordinator(VpnEngine engine, Listener listener) {
        if (engine == null) throw new IllegalArgumentException("A real VPN engine is required");
        this.engine = engine;
        this.listener = listener;
    }

    public synchronized ConnectionStateMachine.State getState() {
        return lifecycle.getState();
    }

    public void connect(VpnEngine.Profile profile) {
        if (profile == null) throw new IllegalArgumentException("Profile is required");
        final long id;
        synchronized (this) {
            ConnectionStateMachine.State current = lifecycle.getState();
            if (current != ConnectionStateMachine.State.IDLE && current != ConnectionStateMachine.State.FAILED) {
                throw new IllegalStateException("Cannot connect while VPN state is " + current);
            }
            id = ++operationId;
            transitionLocked(ConnectionStateMachine.State.PREPARING);
        }
        publishState(ConnectionStateMachine.State.PREPARING);
        try {
            engine.start(profile, new VpnEngine.StartCallback() {
                @Override public void onConnected() {
                    synchronized (VpnEngineCoordinator.this) {
                        if (id != operationId || lifecycle.getState() != ConnectionStateMachine.State.PREPARING) return;
                        transitionLocked(ConnectionStateMachine.State.CONNECTED);
                    }
                    publishState(ConnectionStateMachine.State.CONNECTED);
                }
                @Override public void onFailure(Throwable cause) {
                    synchronized (VpnEngineCoordinator.this) {
                        if (id != operationId || lifecycle.getState() != ConnectionStateMachine.State.PREPARING) return;
                        transitionLocked(ConnectionStateMachine.State.FAILED);
                    }
                    publishState(ConnectionStateMachine.State.FAILED);
                    reportError(cause);
                }
            });
        } catch (Exception error) {
            synchronized (this) {
                if (id == operationId && lifecycle.getState() == ConnectionStateMachine.State.PREPARING) {
                    transitionLocked(ConnectionStateMachine.State.FAILED);
                }
            }
            if (getState() == ConnectionStateMachine.State.FAILED) publishState(ConnectionStateMachine.State.FAILED);
            reportError(error);
        }
    }

    public void disconnect() {
        final long id;
        synchronized (this) {
            if (lifecycle.getState() != ConnectionStateMachine.State.CONNECTED) {
                throw new IllegalStateException("VPN is not connected");
            }
            id = ++operationId;
            transitionLocked(ConnectionStateMachine.State.STOPPING);
        }
        publishState(ConnectionStateMachine.State.STOPPING);
        try {
            engine.stop(new VpnEngine.StopCallback() {
                @Override public void onStopped() {
                    synchronized (VpnEngineCoordinator.this) {
                        if (id != operationId || lifecycle.getState() != ConnectionStateMachine.State.STOPPING) return;
                        transitionLocked(ConnectionStateMachine.State.IDLE);
                    }
                    publishState(ConnectionStateMachine.State.IDLE);
                }
                @Override public void onFailure(Throwable cause) {
                    synchronized (VpnEngineCoordinator.this) {
                        if (id != operationId || lifecycle.getState() != ConnectionStateMachine.State.STOPPING) return;
                        transitionLocked(ConnectionStateMachine.State.FAILED);
                    }
                    publishState(ConnectionStateMachine.State.FAILED);
                    reportError(cause);
                }
            });
        } catch (Exception error) {
            synchronized (this) {
                if (id == operationId && lifecycle.getState() == ConnectionStateMachine.State.STOPPING) {
                    transitionLocked(ConnectionStateMachine.State.FAILED);
                }
            }
            if (getState() == ConnectionStateMachine.State.FAILED) publishState(ConnectionStateMachine.State.FAILED);
            reportError(error);
        }
    }

    /** Must be called while holding this coordinator's monitor. */
    private void transitionLocked(ConnectionStateMachine.State next) {
        lifecycle.transition(next);
    }

    /** Never invoke application code while holding the coordinator lock. */
    private void publishState(ConnectionStateMachine.State state) {
        if (listener == null) return;
        try {
            listener.onStateChanged(state);
        } catch (RuntimeException ignored) {
            // UI/listener bugs must never prevent the engine from starting or stopping.
        }
    }

    private void reportError(Throwable cause) {
        if (listener == null) return;
        try {
            listener.onError(cause == null
                    ? new IllegalStateException("VPN engine failed without a cause") : cause);
        } catch (RuntimeException ignored) {
            // Error presentation is best-effort; lifecycle state remains authoritative.
        }
    }
}
