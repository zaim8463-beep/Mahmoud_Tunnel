package com.mahmoud.tunnel;

/** Small, UI-independent connection lifecycle guard for the future VPN engine adapter. */
public final class ConnectionStateMachine {
    public enum State { IDLE, PREPARING, CONNECTED, STOPPING, FAILED }

    private State state = State.IDLE;

    public synchronized State getState() { return state; }

    /** Applies only legal lifecycle transitions; invalid engine callbacks fail loudly. */
    public synchronized State transition(State next) {
        if (next == null) throw new IllegalArgumentException("next state is required");
        if (next == state) return state;
        boolean allowed;
        switch (state) {
            case IDLE:
                allowed = next == State.PREPARING;
                break;
            case PREPARING:
                allowed = next == State.CONNECTED || next == State.FAILED || next == State.IDLE;
                break;
            case CONNECTED:
                allowed = next == State.STOPPING || next == State.FAILED;
                break;
            case STOPPING:
                allowed = next == State.IDLE || next == State.FAILED;
                break;
            case FAILED:
                allowed = next == State.IDLE || next == State.PREPARING;
                break;
            default:
                allowed = false;
        }
        if (!allowed) {
            throw new IllegalStateException("Illegal VPN lifecycle transition: " + state + " -> " + next);
        }
        state = next;
        return state;
    }
}
