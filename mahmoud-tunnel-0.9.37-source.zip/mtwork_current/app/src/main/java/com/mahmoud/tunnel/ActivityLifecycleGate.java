package com.mahmoud.tunnel;

/** Thread-safe guard for work that must not publish results after its owner is destroyed. */
public final class ActivityLifecycleGate {
    private volatile boolean destroyed;

    /** Marks the owner as permanently destroyed. Safe to call more than once. */
    public void markDestroyed() {
        destroyed = true;
    }

    /** Returns true only while the owner is still alive. */
    public boolean isActive() {
        return !destroyed;
    }
}
