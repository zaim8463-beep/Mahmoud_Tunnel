package com.mahmoud.tunnel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Parses a subscription text containing one multiline profile and/or one-link-per-line entries. */
public final class ProfileImportParser {
    private ProfileImportParser() { }

    public static final class Entry {
        public final String protocol;
        public final String value;
        Entry(String protocol, String value) {
            this.protocol = protocol;
            this.value = value;
        }
    }

    public static List<Entry> parse(String raw) {
        if (raw == null || raw.trim().isEmpty()) return Collections.emptyList();
        String document = stripBom(raw).replace("\r\n", "\n").replace('\r', '\n').trim();
        boolean hasStandaloneShareLinks = false;
        for (String line : document.split("\\r\\n|\\n|\\r")) {
            String protocol = ProfileProtocolDetector.detect(line.trim());
            if (isShareProtocol(protocol) && (isShareLinkText(line.trim()) && ProfileLinkValidator.isValidShareLink(protocol, line.trim()))) {
                hasStandaloneShareLinks = true;
                break;
            }
        }
        String wholeProtocol = ProfileProtocolDetector.detect(document);
        if (!hasStandaloneShareLinks && !"Unknown".equals(wholeProtocol)) {
            if (isShareProtocol(wholeProtocol) && isShareLinkText(document) && !ProfileLinkValidator.isValidShareLink(wholeProtocol, document)) {
                return Collections.emptyList();
            }
            return Collections.singletonList(new Entry(wholeProtocol, document));
        }
        if (document.startsWith("{") || document.startsWith("[")) return Collections.emptyList();

        ArrayList<Entry> entries = new ArrayList<>();
        StringBuilder multiline = new StringBuilder();
        for (String line : document.split("\\r\\n|\\n|\\r", -1)) {
            String candidate = line.trim();
            String lineProtocol = ProfileProtocolDetector.detect(candidate);
            if (!"Unknown".equals(lineProtocol)
                    && (!isShareProtocol(lineProtocol) || !isShareLinkText(candidate) || ProfileLinkValidator.isValidShareLink(lineProtocol, candidate))) {
                flushMultiline(multiline, entries);
                entries.add(new Entry(lineProtocol, candidate));
            } else {
                if (multiline.length() > 0) multiline.append('\n');
                multiline.append(line);
            }
        }
        flushMultiline(multiline, entries);
        return Collections.unmodifiableList(entries);
    }

    private static boolean isShareLinkText(String value) {
        return value != null && !value.startsWith("{") && !value.startsWith("[")
                && value.contains("://");
    }

    private static boolean isShareProtocol(String protocol) {
        return !"Unknown".equals(protocol) && !"OpenVPN".equals(protocol);
    }

    private static String stripBom(String value) {
        return value != null && !value.isEmpty() && value.charAt(0) == '\uFEFF'
                ? value.substring(1) : value;
    }

    private static void flushMultiline(StringBuilder buffer, List<Entry> entries) {
        String candidate = buffer.toString().trim();
        buffer.setLength(0);
        if (candidate.isEmpty()) return;
        String protocol = ProfileProtocolDetector.detect(candidate);
        if (!"Unknown".equals(protocol)
                && (!isShareProtocol(protocol) || !isShareLinkText(candidate)
                || ProfileLinkValidator.isValidShareLink(protocol, candidate))) {
            entries.add(new Entry(protocol, candidate));
        }
    }
}
