package com.mahmoud.tunnel;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Converts common sing-box share links into a complete, conservative TUN client config. */
public final class SingBoxConfigBuilder {
    private SingBoxConfigBuilder() { }

    public static String build(String protocol, String raw, String profileName) throws Exception {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("Configuration is empty");
        String value = raw.trim();
        JSONObject root;
        if (value.startsWith("{") || value.startsWith("[")) {
            root = normalizeJson(value);
        } else {
            JSONObject outbound;
            String scheme = value.substring(0, Math.max(0, value.indexOf("://"))).toLowerCase(Locale.ROOT);
            switch (scheme) {
                case "vless": outbound = vless(value); break;
                case "trojan": outbound = trojan(value); break;
                case "ss": outbound = shadowsocks(value); break;
                case "vmess": outbound = vmess(value); break;
                case "socks": case "socks5": case "socks5h": case "socks4": outbound = simpleProxy("socks", value); break;
                case "http": case "https": outbound = simpleProxy("http", value); break;
                default: throw new IllegalArgumentException("This protocol is detected but not yet convertible by the built-in sing-box adapter: " + protocol);
            }
            root = wrap(outbound);
        }
        // The native engine performs the authoritative version-specific schema validation.
        return root.toString();
    }

    private static JSONObject normalizeJson(String value) throws Exception {
        JSONObject root;
        if (value.startsWith("[")) {
            JSONArray outbounds = new JSONArray(value);
            root = new JSONObject().put("outbounds", outbounds);
        } else root = new JSONObject(value);
        if (!(root.opt("outbounds") instanceof JSONArray)) {
            if (root.has("type")) root = wrap(root);
            else throw new IllegalArgumentException("JSON must be a sing-box config or a single outbound object");
        } else {
            JSONArray outbounds = root.getJSONArray("outbounds");
            if (outbounds.length() == 0) throw new IllegalArgumentException("No outbound proxy was found in JSON");
            if (!hasTunInbound(root.optJSONArray("inbounds"))) {
                JSONArray inbounds = root.optJSONArray("inbounds");
                if (inbounds == null) inbounds = new JSONArray();
                inbounds.put(defaultInbounds().getJSONObject(0));
                root.put("inbounds", inbounds);
            }
            if (!root.has("route")) root.put("route", defaultRoute(firstProxyTag(outbounds)));
        }
        return root;
    }

    private static JSONObject wrap(JSONObject proxy) throws Exception {
        proxy.put("tag", "proxy");
        JSONArray outbounds = new JSONArray().put(proxy)
                .put(new JSONObject().put("type", "direct").put("tag", "direct"))
                .put(new JSONObject().put("type", "block").put("tag", "block"));
        return new JSONObject()
                .put("log", new JSONObject().put("level", "warn"))
                .put("dns", new JSONObject().put("servers", new JSONArray()
                        .put(new JSONObject().put("tag", "dns-remote").put("type", "udp").put("server", "1.1.1.1").put("server_port", 53).put("detour", "proxy")))
                        .put("final", "dns-remote"))
                .put("inbounds", defaultInbounds())
                .put("outbounds", outbounds)
                .put("route", defaultRoute("proxy"));
    }

    private static JSONArray defaultInbounds() throws Exception {
        return new JSONArray().put(new JSONObject().put("type", "tun").put("tag", "tun-in")
                .put("address", new JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
                .put("auto_route", true).put("strict_route", true).put("stack", "system").put("mtu", 9000));
    }

    private static boolean hasTunInbound(JSONArray inbounds) {
        if (inbounds == null) return false;
        for (int i = 0; i < inbounds.length(); i++) {
            JSONObject inbound = inbounds.optJSONObject(i);
            if (inbound != null && "tun".equalsIgnoreCase(inbound.optString("type"))) return true;
        }
        return false;
    }

    private static JSONObject defaultRoute(String tag) throws Exception {
        return new JSONObject().put("auto_detect_interface", true).put("final", tag);
    }

    private static String firstProxyTag(JSONArray outbounds) throws Exception {
        for (int i = 0; i < outbounds.length(); i++) {
            JSONObject o = outbounds.optJSONObject(i);
            if (o != null && !"direct".equals(o.optString("type")) && !"block".equals(o.optString("type"))) {
                String tag = o.optString("tag", "");
                if (tag.isEmpty()) { tag = "proxy"; o.put("tag", tag); }
                return tag;
            }
        }
        return "direct";
    }

    private static JSONObject vless(String value) throws Exception {
        URI uri = new URI(value);
        requireEndpoint(uri);
        String uuid = decode(uri.getRawUserInfo());
        if (uuid.isEmpty()) throw new IllegalArgumentException("VLESS UUID is missing");
        JSONObject out = endpoint("vless", uri).put("uuid", uuid);
        String flow = query(uri, "flow");
        if (!flow.isEmpty()) out.put("flow", flow);
        String encryption = query(uri, "encryption");
        if (!encryption.isEmpty() && !"none".equalsIgnoreCase(encryption))
            throw new IllegalArgumentException("Unsupported VLESS encryption mode: " + encryption);
        String security = query(uri, "security").toLowerCase(Locale.ROOT);
        if (!security.isEmpty() && !"tls".equals(security) && !"reality".equals(security) && !"none".equals(security))
            throw new IllegalArgumentException("Unsupported VLESS security mode: " + security);
        if ("tls".equals(security) || "reality".equals(security) || "1".equals(query(uri, "tls"))) {
            JSONObject tls = tls(uri, "reality".equals(security));
            out.put("tls", tls);
        }
        addTransport(out, uri);
        return out;
    }

    private static JSONObject trojan(String value) throws Exception {
        URI uri = new URI(value);
        requireEndpoint(uri);
        String password = decode(uri.getRawUserInfo());
        if (password.isEmpty()) throw new IllegalArgumentException("Trojan password is missing");
        JSONObject out = endpoint("trojan", uri).put("password", password)
                .put("tls", tls(uri, false));
        addTransport(out, uri);
        return out;
    }

    private static JSONObject shadowsocks(String value) throws Exception {
        String noFragment = value.split("#", 2)[0];
        if (noFragment.toLowerCase(Locale.ROOT).contains("?plugin="))
            throw new IllegalArgumentException("Shadowsocks SIP002 plugins are not supported by this converter yet");
        String body = noFragment.substring(noFragment.indexOf("://") + 3);
        String methodPassword, endpoint;
        int at = body.lastIndexOf('@');
        if (at >= 0) {
            methodPassword = body.substring(0, at);
            endpoint = body.substring(at + 1);
            if (!methodPassword.contains(":")) methodPassword = decodeBase64(methodPassword);
        } else {
            String decoded = decodeBase64(body);
            int decodedAt = decoded.lastIndexOf('@');
            if (decodedAt < 0) throw new IllegalArgumentException("Invalid Shadowsocks share link");
            methodPassword = decoded.substring(0, decodedAt);
            endpoint = decoded.substring(decodedAt + 1);
        }
        int colon = methodPassword.indexOf(':');
        if (colon <= 0 || colon == methodPassword.length() - 1) throw new IllegalArgumentException("Shadowsocks method/password is invalid");
        URI server = new URI("ss://" + endpoint);
        requireEndpoint(server);
        return endpoint("shadowsocks", server).put("method", decode(methodPassword.substring(0, colon)))
                .put("password", decode(methodPassword.substring(colon + 1)));
    }

    private static JSONObject vmess(String value) throws Exception {
        String payload = value.substring(value.indexOf("://") + 3).trim();
        JSONObject source = new JSONObject(decodeBase64(payload));
        String host = source.optString("add", source.optString("address", ""));
        int port = source.optInt("port", 0);
        String uuid = source.optString("id", "");
        if (host.isEmpty() || port < 1 || port > 65535 || uuid.isEmpty()) throw new IllegalArgumentException("VMess address, port or UUID is missing");
        if (source.optInt("aid", 0) != 0) throw new IllegalArgumentException("This VMess profile uses a legacy alterId value; import a modern alterId=0 profile");
        JSONObject out = new JSONObject().put("type", "vmess").put("server", host).put("server_port", port).put("uuid", uuid).put("security", "auto");
        String network = source.optString("net", "tcp").toLowerCase(Locale.ROOT);
        if ("ws".equals(network)) {
            JSONObject transport = new JSONObject().put("type", "ws");
            String path = source.optString("path", ""); if (!path.isEmpty()) transport.put("path", path);
            String hostHeader = source.optString("host", "");
            if (!hostHeader.isEmpty()) transport.put("headers", new JSONObject().put("Host", hostHeader));
            out.put("transport", transport);
        } else if (!"tcp".equals(network) && !network.isEmpty()) {
            throw new IllegalArgumentException("VMess transport is not supported by this profile converter: " + network);
        }
        String tls = source.optString("tls", "");
        if ("tls".equalsIgnoreCase(tls)) {
            JSONObject tlsConfig = new JSONObject().put("enabled", true);
            String sni = source.optString("sni", source.optString("host", ""));
            if (!sni.isEmpty()) tlsConfig.put("server_name", sni);
            tlsConfig.put("utls", new JSONObject().put("enabled", true).put("fingerprint", "chrome"));
            out.put("tls", tlsConfig);
        }
        return out;
    }

    private static JSONObject simpleProxy(String type, String value) throws Exception {
        URI uri = new URI(value);
        requireEndpoint(uri);
        JSONObject out = endpoint(type, uri);
        if ("socks".equals(type)) out.put("version", "socks4".equalsIgnoreCase(uri.getScheme()) ? "4" : "5");
        if ("https".equalsIgnoreCase(uri.getScheme())) {
            out.put("tls", new JSONObject().put("enabled", true).put("server_name", uri.getHost()));
        }
        String userInfo = decode(uri.getRawUserInfo());
        if (!userInfo.isEmpty()) {
            int colon = userInfo.indexOf(':');
            if (colon >= 0) {
                out.put("username", userInfo.substring(0, colon));
                out.put("password", userInfo.substring(colon + 1));
            } else if ("http".equals(type)) {
                out.put("username", userInfo);
            }
        }
        return out;
    }

    private static JSONObject endpoint(String type, URI uri) throws Exception {
        return new JSONObject().put("type", type).put("server", uri.getHost()).put("server_port", uri.getPort());
    }

    private static JSONObject tls(URI uri, boolean reality) throws Exception {
        JSONObject tls = new JSONObject().put("enabled", true);
        String sni = query(uri, "sni"); if (sni.isEmpty()) sni = query(uri, "peer");
        if (sni.isEmpty()) sni = uri.getHost();
        if (!sni.isEmpty()) tls.put("server_name", sni);
        String fp = query(uri, "fp");
        if (!fp.isEmpty()) tls.put("utls", new JSONObject().put("enabled", true).put("fingerprint", fp));
        String insecure = query(uri, "allowInsecure");
        if (insecure.isEmpty()) insecure = query(uri, "insecure");
        if ("1".equals(insecure) || "true".equalsIgnoreCase(insecure)) tls.put("insecure", true);
        if (reality) {
            String publicKey = query(uri, "pbk");
            if (publicKey.isEmpty()) publicKey = query(uri, "publicKey");
            if (publicKey.isEmpty()) throw new IllegalArgumentException("VLESS Reality public key (pbk) is missing");
            JSONObject realityConfig = new JSONObject().put("enabled", true).put("public_key", publicKey);
            String shortId = query(uri, "sid"); if (shortId.isEmpty()) shortId = query(uri, "shortId");
            if (!shortId.isEmpty()) realityConfig.put("short_id", shortId);
            tls.put("reality", realityConfig);
        }
        return tls;
    }

    private static void addTransport(JSONObject out, URI uri) throws Exception {
        String type = query(uri, "type");
        if (type.isEmpty() || "tcp".equals(type)) return;
        JSONObject transport = new JSONObject();
        if ("ws".equals(type) || "httpupgrade".equals(type) || "grpc".equals(type)) {
            transport.put("type", type);
            if ("ws".equals(type) || "httpupgrade".equals(type)) {
                String path = query(uri, "path"); if (!path.isEmpty()) transport.put("path", path);
                String host = query(uri, "host"); if (!host.isEmpty()) transport.put("headers", new JSONObject().put("Host", host));
            } else {
                String service = query(uri, "serviceName"); if (service.isEmpty()) service = query(uri, "service_name");
                if (!service.isEmpty()) transport.put("service_name", service);
            }
            out.put("transport", transport);
        } else throw new IllegalArgumentException("Unsupported transport: " + type);
    }

    private static void requireEndpoint(URI uri) {
        if (uri.getHost() == null || uri.getHost().isEmpty() || uri.getPort() < 1 || uri.getPort() > 65535)
            throw new IllegalArgumentException("Server hostname and valid port are required");
    }

    private static String query(URI uri, String key) throws Exception {
        String q = uri.getRawQuery(); if (q == null) return "";
        for (String item : q.split("&")) {
            int eq = item.indexOf('=');
            String k = URLDecoder.decode(eq < 0 ? item : item.substring(0, eq), "UTF-8");
            if (key.equalsIgnoreCase(k)) return decode(URLDecoder.decode(eq < 0 ? "" : item.substring(eq + 1), "UTF-8"));
        }
        return "";
    }

    private static String decode(String value) throws Exception {
        return value == null ? "" : URLDecoder.decode(value.replace("+", "%2B"), "UTF-8");
    }

    private static String decodeBase64(String value) throws Exception {
        String clean = value.trim().replace('-', '+').replace('_', '/');
        while (clean.length() % 4 != 0) clean += "=";
        byte[] bytes = Base64.decode(clean, Base64.DEFAULT);
        return new String(bytes, StandardCharsets.UTF_8).trim();
    }
}
