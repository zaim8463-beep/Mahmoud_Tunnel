package com.mahmoud.tunnel;

import java.net.InetAddress;
import java.net.URI;
import java.util.Locale;

/** Structural validation for provider subscription URLs; it does not guarantee provider trust. */
public final class SubscriptionUrlValidator {
    private SubscriptionUrlValidator() { }

    public static boolean isValidHttpsUrl(String value) {
        if (value == null) return false;
        String candidate = value.trim();
        if (candidate.isEmpty() || containsWhitespace(candidate)) return false;
        try {
            URI uri = new URI(candidate);
            if (!"https".equals(uri.getScheme() == null ? null : uri.getScheme().toLowerCase(Locale.ROOT))) return false;
            if (!uri.isAbsolute() || uri.getHost() == null || uri.getHost().trim().isEmpty()) return false;
            if (uri.getRawUserInfo() != null || uri.getRawFragment() != null) return false;
            int port = uri.getPort();
            if (port != -1 && (port < 1 || port > 65535)) return false;
            return isPublicHost(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Avoid fetching subscription URLs aimed at local devices or private network services. */
    private static boolean isPublicHost(String rawHost) {
        String host = rawHost.toLowerCase(Locale.ROOT);
        while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
        if (host.isEmpty()) return false;
        // Reject legacy numeric host spellings (single-integer, shortened IPv4,
        // octal and hexadecimal forms). Some URL stacks interpret these as IPs.
        if (host.matches("(?i)(?:[0-9]+|0x[0-9a-f]+)(?:\\.(?:[0-9]+|0x[0-9a-f]+)){0,3}")) {
            String[] labels = host.split("\\.", -1);
            boolean canonicalIpv4 = labels.length == 4;
            for (String label : labels) {
                if (label.startsWith("0x") || (label.length() > 1 && label.charAt(0) == '0')) {
                    canonicalIpv4 = false;
                }
            }
            if (!canonicalIpv4) return false;
        }
        if (host.equals("localhost") || host.endsWith(".localhost") || host.endsWith(".local")
                || host.endsWith(".internal") || host.endsWith(".test")) return false;

        // Parse only literal IP addresses. Never perform DNS resolution during validation.
        if (host.indexOf(':') >= 0) {
            try {
                String literal = host.startsWith("[") && host.endsWith("]")
                        ? host.substring(1, host.length() - 1) : host;
                InetAddress address = InetAddress.getByName(literal);
                return isPublicAddress(address);
            } catch (Exception ignored) {
                return false;
            }
        }
        if (host.matches("[0-9.]+")) {
            String[] parts = host.split("\\.", -1);
            if (parts.length != 4) return false;
            int[] octets = new int[4];
            for (int i = 0; i < 4; i++) {
                if (parts[i].isEmpty() || parts[i].length() > 3
                    || (parts[i].length() > 1 && parts[i].charAt(0) == '0')) return false;
                try { octets[i] = Integer.parseInt(parts[i]); }
                catch (NumberFormatException ignored) { return false; }
                if (octets[i] > 255) return false;
            }
            int a = octets[0], b = octets[1];
            if (a == 0 || a == 10 || a == 127 || a >= 224) return false;
            if (a == 100 && b >= 64 && b <= 127) return false;
            if (a == 169 && b == 254) return false;
            if (a == 172 && b >= 16 && b <= 31) return false;
            if (a == 192 && (b == 168 || (b == 0 && (octets[2] == 0 || octets[2] == 2))
                    || (b == 88 && octets[2] == 99))) return false;
            if (a == 198 && b == 51 && octets[2] == 100) return false;
            if (a == 203 && b == 0 && octets[2] == 113) return false;
            if (a == 198 && (b == 18 || b == 19)) return false;
            return !(a == 255 && b == 255 && octets[2] == 255 && octets[3] == 255);
        }
        return host.contains(".");
    }

    private static boolean isPublicAddress(InetAddress address) {
        if (address.isAnyLocalAddress() || address.isLoopbackAddress()
                || address.isLinkLocalAddress() || address.isSiteLocalAddress()
                || address.isMulticastAddress()) return false;
        byte[] bytes = address.getAddress();
        // IPv6 unique-local (fc00::/7) and deprecated site-local (fec0::/10).
        if (bytes.length == 16) {
            int first = bytes[0] & 0xff;
            int second = bytes[1] & 0xff;
            // Only accept IPv6 global-unicast space (2000::/3). This excludes
            // unspecified, loopback, link-local, ULA, multicast, and other
            // non-global ranges even if the JDK does not classify them specially.
            if ((first & 0xe0) != 0x20) return false;
            // Exclude documentation and transition/special-purpose prefixes.
            if (first == 0x20 && second == 0x01) {
                int third = bytes[2] & 0xff;
                if (third == 0x0d || third <= 0x01) return false; // 2001:db8::/32, 2001::/23
            }
            if (first == 0x20 && second == 0x02) return false; // 6to4 may embed non-public IPv4
            if (first == 0x3f && second == 0xff) return false; // 3fff::/20 documentation
        }
        return true;
    }

    private static boolean containsWhitespace(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (Character.isWhitespace(value.charAt(i)) || Character.isISOControl(value.charAt(i))) return true;
        }
        return false;
    }
}
