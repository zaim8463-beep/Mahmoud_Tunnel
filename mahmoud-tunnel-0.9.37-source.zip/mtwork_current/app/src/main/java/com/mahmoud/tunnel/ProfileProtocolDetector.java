package com.mahmoud.tunnel;

import org.json.JSONArray;
import org.json.JSONObject;

/** Identifies supported share-link schemes and sing-box outbound JSON types. */
public final class ProfileProtocolDetector {
    private ProfileProtocolDetector() { }

    private static boolean isPlainHttpProxyUri(String value) {
        try {
            java.net.URI uri = new java.net.URI(value);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return false;
            // A normal web/subscription URL must not be mistaken for a proxy.
            String path = uri.getRawPath();
            if (path != null && !path.isEmpty() && !path.equals("/")) return false;
            return uri.getHost() != null && uri.getPort() > 0 && uri.getUserInfo() != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isWireGuardConfig(String value) {
        String lower = value.toLowerCase(java.util.Locale.ROOT);
        return lower.contains("[interface]") && lower.contains("[peer]")
                && lower.matches("(?s).*\\bprivatekey\\s*=\\s*[^\\r\\n]+.*")
                && lower.matches("(?s).*\\bpublickey\\s*=\\s*[^\\r\\n]+.*")
                && lower.matches("(?s).*\\bendpoint\\s*=\\s*[^\\r\\n]+.*");
    }

    private static boolean isOpenVpnConfig(String value) {
        boolean client = false;
        boolean remote = false;
        boolean tun = false;
        for (String line : value.split("\\r\\n|\\n|\\r")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith(";")) continue;
            String lower = trimmed.toLowerCase(java.util.Locale.ROOT);
            if (lower.matches("client(?:\\s+.*)?")) client = true;
            if (lower.matches("remote\\s+[^\\s]+(?:\\s+\\d{1,5})?(?:\\s+.*)?")) remote = true;
            if (lower.matches("dev\\s+tun\\d*")) tun = true;
        }
        return client && remote && tun;
    }

    public static String detect(String value) {
        if (value == null) return "Unknown";
        String v = value.trim();
        if (!v.isEmpty() && v.charAt(0) == '\uFEFF') v = v.substring(1).trim();
        if (v.isEmpty()) return "Unknown";
        String lower = v.toLowerCase(java.util.Locale.ROOT);
        if (lower.startsWith("vless://")) return "VLESS";
        if (lower.startsWith("vmess://")) return "VMess";
        if (lower.startsWith("trojan://")) return "Trojan";
        if (lower.startsWith("wireguard://") || lower.startsWith("wg://")) return "WireGuard";
        if (isWireGuardConfig(v)) return "WireGuard";
        if (isOpenVpnConfig(v)) return "OpenVPN";
        if (lower.startsWith("ssh://")) return "SSH";
        if (lower.startsWith("ss://")) return "Shadowsocks";
        if (lower.startsWith("hysteria2://") || lower.startsWith("hy2://")) return "Hysteria2";
        if (lower.startsWith("hysteria://")) return "Hysteria";
        if (lower.startsWith("tuic://")) return "TUIC";
        if (lower.startsWith("anytls://")) return "AnyTLS";
        if (lower.startsWith("shadowtls://")) return "ShadowTLS";
        if (lower.startsWith("socks://") || lower.startsWith("socks4://") || lower.startsWith("socks5://") || lower.startsWith("socks5h://")) return "SOCKS";
        if (isPlainHttpProxyUri(v)) return "HTTP Proxy";
        if (v.startsWith("{") || v.startsWith("[")) {
            try {
                JSONArray outbounds;
                if (v.startsWith("[")) {
                    outbounds = new JSONArray(v);
                } else {
                    JSONObject root = new JSONObject(v);
                    Object rawOutbounds = root.opt("outbounds");
                    if (rawOutbounds instanceof JSONArray) outbounds = (JSONArray) rawOutbounds;
                    else outbounds = new JSONArray().put(root);
                }
                for (int i = 0; i < outbounds.length(); i++) {
                    JSONObject outbound = outbounds.optJSONObject(i);
                    if (outbound == null) continue;
                    String type = outbound.optString("type", outbound.optString("protocol", "")).toLowerCase(java.util.Locale.ROOT);
                    switch (type) {
                        case "vless": return "VLESS";
                        case "vmess": return "VMess";
                        case "trojan": return "Trojan";
                        case "wireguard": return "WireGuard";
                        case "ssh": return "SSH";
                        case "shadowsocks": return "Shadowsocks";
                        case "hysteria": return "Hysteria";
                        case "hysteria2": return "Hysteria2";
                        case "tuic": return "TUIC";
                        case "anytls": return "AnyTLS";
                        case "shadowtls": return "ShadowTLS";
                        case "socks": return "SOCKS";
                        case "http": return "HTTP Proxy";
                        default: break;
                    }
                }
            } catch (Exception ignored) {
                return "Unknown";
            }
        }
        return "Unknown";
    }
}
