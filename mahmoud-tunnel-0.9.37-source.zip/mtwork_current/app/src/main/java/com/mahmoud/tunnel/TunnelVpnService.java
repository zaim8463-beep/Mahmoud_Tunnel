package com.mahmoud.tunnel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.IpPrefix;
import android.net.ProxyInfo;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.system.OsConstants;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import io.nekohasekai.libbox.CommandServer;
import io.nekohasekai.libbox.CommandServerHandler;
import io.nekohasekai.libbox.Libbox;
import io.nekohasekai.libbox.InterfaceUpdateListener;
import io.nekohasekai.libbox.NetworkInterfaceIterator;
import io.nekohasekai.libbox.NetworkInterface;
import io.nekohasekai.libbox.OverrideOptions;
import io.nekohasekai.libbox.PlatformInterface;
import io.nekohasekai.libbox.RoutePrefix;
import io.nekohasekai.libbox.RoutePrefixIterator;
import io.nekohasekai.libbox.SetupOptions;
import io.nekohasekai.libbox.StringBox;
import io.nekohasekai.libbox.StringIterator;
import io.nekohasekai.libbox.SystemProxyStatus;
import io.nekohasekai.libbox.TunOptions;

import java.io.File;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Real Android VpnService host for the version-pinned sing-box libbox engine. */
public final class TunnelVpnService extends VpnService {
    public static final String ACTION_START = "com.mahmoud.tunnel.action.START";
    public static final String ACTION_STOP = "com.mahmoud.tunnel.action.STOP";
    public static final String ACTION_STATE = "com.mahmoud.tunnel.action.STATE";
    public static final String EXTRA_CONFIG = "config";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_ERROR = "error";
    private static final String CHANNEL_ID = "vpn_tunnel_status";
    private static final int NOTIFICATION_ID = 7301;
    private static final String TAG = "MahmoudTunnel";
    private static volatile boolean libboxSetup;

    private final ExecutorService engineExecutor = Executors.newSingleThreadExecutor();
    private volatile CommandServer commandServer;
    private volatile ParcelFileDescriptor tunDescriptor;
    private volatile PlatformInterface platformInterface;
    private volatile CommandServerHandler commandHandler;
    private volatile String activeConfig;
    private volatile boolean stopping;
    private volatile ConnectivityManager.NetworkCallback defaultNetworkCallback;
    private volatile InterfaceUpdateListener defaultInterfaceListener;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            engineExecutor.execute(this::stopEngine);
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        String config = intent.getStringExtra(EXTRA_CONFIG);
        if (config == null || config.trim().isEmpty()) {
            publishState("FAILED", "VPN configuration is empty");
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        activeConfig = config;
        stopping = false;
        startForegroundCompat();
        engineExecutor.execute(() -> startEngine(config));
        return START_NOT_STICKY;
    }

    private void startEngine(String config) {
        try {
            if (commandServer != null || tunDescriptor != null) stopEngineInternal(false);
            stopping = false;
            activeConfig = config;
            ensureLibboxSetup();
            Libbox.checkConfig(config);
            platformInterface = createPlatformInterface();
            commandHandler = createCommandHandler();
            CommandServer server = new CommandServer(commandHandler, platformInterface);
            commandServer = server;
            server.start();
            server.startOrReloadService(config, new OverrideOptions());
            // StartOrReloadService returns only after sing-box has accepted and started
            // the configuration. openTun() records the established Android interface;
            // publish CONNECTED only after both stages have completed.
            if (tunDescriptor != null) {
                publishState("CONNECTED", null);
                updateNotification("Secure tunnel connected • Mahmoud Tunnel");
            } else {
                publishState("STARTING", null);
                updateNotification("Waiting for VPN interface…");
            }
        } catch (Throwable error) {
            Log.e(TAG, "sing-box startup failed", error);
            stopEngineInternal(false);
            stopForeground(true);
            publishState("FAILED", safeMessage(error));
            stopSelf();
        }
    }

    private synchronized void ensureLibboxSetup() throws Exception {
        if (!libboxSetup) {
            Libbox.setup(createSetupOptions());
            libboxSetup = true;
        }
    }

    private SetupOptions createSetupOptions() {
        File working = getExternalFilesDir(null);
        if (working == null) working = getFilesDir();
        SetupOptions options = new SetupOptions();
        options.setBasePath(getFilesDir().getAbsolutePath());
        options.setWorkingPath(working.getAbsolutePath());
        options.setTempPath(getCacheDir().getAbsolutePath());
        options.setFixAndroidStack(true);
        options.setLogMaxLines(1500);
        options.setDebug(false);
        options.setAppVersion(String.valueOf(BuildConfig.VERSION_CODE));
        options.setAppMarketingVersion(BuildConfig.VERSION_NAME);
        options.setCrashReportSource("MahmoudTunnel");
        return options;
    }

    private PlatformInterface createPlatformInterface() {
        InvocationHandler handler = (proxy, method, args) -> {
            String name = method.getName();
            if ("toString".equals(name)) return "MahmoudTunnelPlatformInterface";
            if ("hashCode".equals(name)) return System.identityHashCode(proxy);
            if ("equals".equals(name)) return proxy == (args == null ? null : args[0]);
            if ("usePlatformAutoDetectInterfaceControl".equals(name)) return true;
            if ("autoDetectInterfaceControl".equals(name)) {
                int fd = ((Number) args[0]).intValue();
                if (!protect(fd)) throw new IllegalStateException("Could not protect sing-box socket from VPN routing");
                return null;
            }
            if ("openTun".equals(name)) return openTun((TunOptions) args[0]);
            if ("getInterfaces".equals(name)) return getAndroidInterfaces();
            if ("startDefaultInterfaceMonitor".equals(name)) {
                startDefaultInterfaceMonitor((InterfaceUpdateListener) args[0]);
                return null;
            }
            if ("closeDefaultInterfaceMonitor".equals(name)) {
                closeDefaultInterfaceMonitor();
                return null;
            }
            if ("underNetworkExtension".equals(name) || "includeAllNetworks".equals(name)
                    || "usePlatformBridge".equals(name) || "usePlatformShell".equals(name)) return false;
            if ("tailscaleHostname".equals(name)) return Build.MANUFACTURER + " " + Build.MODEL;
            if ("lookupSFTPServer".equals(name) || "readSystemSSHHostKey".equals(name)) return "";
            if ("findConnectionOwner".equals(name)) {
                return Libbox.findConnectionOwner(((Number) args[0]).intValue(), (String) args[1],
                        ((Number) args[2]).intValue(), (String) args[3], ((Number) args[4]).intValue());
            }
            if ("localDNSTransport".equals(name) || "readWIFIState".equals(name)
                    || "lookupUser".equals(name) || "createBridge".equals(name)
                    || "openShellSession".equals(name)) return null;
            // Network, neighbor, and notification hooks are optional. A dynamic proxy must
            // still return a correctly typed value for primitive-returning API methods;
            // returning null here would cause an unboxing NullPointerException in libbox.
            return primitiveDefault(method.getReturnType());
        };
        return (PlatformInterface) Proxy.newProxyInstance(PlatformInterface.class.getClassLoader(),
                new Class<?>[]{PlatformInterface.class}, handler);
    }

    private CommandServerHandler createCommandHandler() {
        InvocationHandler handler = (proxy, method, args) -> {
            String name = method.getName();
            if ("toString".equals(name)) return "MahmoudTunnelCommandHandler";
            if ("hashCode".equals(name)) return System.identityHashCode(proxy);
            if ("equals".equals(name)) return proxy == (args == null ? null : args[0]);
            if ("serviceStop".equals(name)) {
                engineExecutor.execute(() -> stopEngine());
                return null;
            }
            if ("serviceReload".equals(name)) {
                String config = activeConfig;
                if (config != null && commandServer != null) commandServer.startOrReloadService(config, new OverrideOptions());
                return null;
            }
            if ("getSystemProxyStatus".equals(name)) return new SystemProxyStatus();
            if ("connectSSHAgent".equals(name)) return -1;
            if ("writeDebugMessage".equals(name)) { Log.d(TAG, String.valueOf(args[0])); return null; }
            return primitiveDefault(method.getReturnType());
        };
        return (CommandServerHandler) Proxy.newProxyInstance(CommandServerHandler.class.getClassLoader(),
                new Class<?>[]{CommandServerHandler.class}, handler);
    }

    private int openTun(TunOptions options) throws Exception {
        if (VpnService.prepare(this) != null) throw new IllegalStateException("Android VPN permission has not been granted");
        Builder builder = new Builder().setSession("Mahmoud Tunnel").setMtu(options.getMTU());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false);

        addAddressPrefixes(builder, options.getInet4Address());
        addAddressPrefixes(builder, options.getInet6Address());

        if (options.getAutoRoute()) {
            StringBox dnsMode = options.getDNSMode();
            boolean dnsEnabled = dnsMode == null || !"disabled".equalsIgnoreCase(dnsMode.getValue());
            if (dnsEnabled) addDnsServers(builder, options.getDNSServerAddress());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                boolean v4 = addRoutePrefixes(builder, options.getInet4RouteAddress());
                boolean v6 = addRoutePrefixes(builder, options.getInet6RouteAddress());
                addExcludedRoutes(builder, options.getInet4RouteExcludeAddress());
                addExcludedRoutes(builder, options.getInet6RouteExcludeAddress());
                if (!v4 && hasNext(options.getInet4Address())) builder.addRoute("0.0.0.0", 0);
                if (!v6 && hasNext(options.getInet6Address())) builder.addRoute("::", 0);
            } else {
                addRoutePrefixes(builder, options.getInet4RouteRange());
                addRoutePrefixes(builder, options.getInet6RouteRange());
            }
            addPackages(builder, options.getIncludePackage(), true);
            addPackages(builder, options.getExcludePackage(), false);
        }
        if (options.isHTTPProxyEnabled() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setHttpProxy(ProxyInfo.buildDirectProxy(options.getHTTPProxyServer(),
                    options.getHTTPProxyServerPort(), collectStrings(options.getHTTPProxyBypassDomain())));
        }
        ParcelFileDescriptor established = builder.establish();
        if (established == null) throw new IllegalStateException("Android refused to establish the VPN interface");

        // Follow the upstream sing-box Android VpnService ownership contract:
        // keep the ParcelFileDescriptor alive for the lifetime of the engine and
        // return its fd to libbox. Closing this descriptor is part of orderly
        // shutdown, after closeService()/close(); do not detach or duplicate it.
        ParcelFileDescriptor old = tunDescriptor;
        tunDescriptor = established;
        if (old != null) try { old.close(); } catch (Exception ignored) { }
        return established.getFd();
    }

    private synchronized void startDefaultInterfaceMonitor(InterfaceUpdateListener listener) {
        closeDefaultInterfaceMonitor();
        ConnectivityManager connectivity = getSystemService(ConnectivityManager.class);
        if (connectivity == null || listener == null) return;
        defaultInterfaceListener = listener;
        ConnectivityManager.NetworkCallback callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) { publishDefaultInterface(connectivity, network); }
            @Override public void onLinkPropertiesChanged(Network network, LinkProperties properties) {
                publishDefaultInterface(connectivity, network);
            }
            @Override public void onLost(Network network) {
                Network active = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? connectivity.getActiveNetwork() : null;
                if (active != null) publishDefaultInterface(connectivity, active);
                else publishDefaultInterface(null, null);
            }
        };
        defaultNetworkCallback = callback;
        try {
            connectivity.registerDefaultNetworkCallback(callback);
            Network active = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? connectivity.getActiveNetwork() : null;
            if (active != null) publishDefaultInterface(connectivity, active);
        } catch (Exception error) {
            defaultNetworkCallback = null;
            defaultInterfaceListener = null;
            Log.w(TAG, "Could not monitor default network", error);
        }
    }

    private synchronized void closeDefaultInterfaceMonitor() {
        ConnectivityManager.NetworkCallback callback = defaultNetworkCallback;
        defaultNetworkCallback = null;
        defaultInterfaceListener = null;
        if (callback != null) {
            ConnectivityManager connectivity = getSystemService(ConnectivityManager.class);
            if (connectivity != null) {
                try { connectivity.unregisterNetworkCallback(callback); }
                catch (Exception error) { Log.d(TAG, "Network callback already unregistered", error); }
            }
        }
    }

    private void publishDefaultInterface(ConnectivityManager connectivity, Network network) {
        InterfaceUpdateListener listener = defaultInterfaceListener;
        if (listener == null) return;
        if (connectivity == null || network == null) {
            try { listener.updateDefaultInterface("", -1, false, false); }
            catch (Exception error) { Log.w(TAG, "Default interface update failed", error); }
            return;
        }
        try {
            LinkProperties properties = connectivity.getLinkProperties(network);
            if (properties == null || properties.getInterfaceName() == null) return;
            java.net.NetworkInterface systemInterface = java.net.NetworkInterface.getByName(properties.getInterfaceName());
            if (systemInterface == null) return;
            listener.updateDefaultInterface(properties.getInterfaceName(), systemInterface.getIndex(), false, false);
        } catch (Exception error) {
            Log.w(TAG, "Could not resolve default network interface", error);
        }
    }

    private NetworkInterfaceIterator getAndroidInterfaces() throws Exception {
        java.util.ArrayList<NetworkInterface> result = new java.util.ArrayList<>();
        ConnectivityManager connectivity = getSystemService(ConnectivityManager.class);
        if (connectivity == null) return networkIterator(result);
        java.util.Enumeration<java.net.NetworkInterface> system = java.net.NetworkInterface.getNetworkInterfaces();
        java.util.HashMap<String, java.net.NetworkInterface> byName = new java.util.HashMap<>();
        if (system != null) while (system.hasMoreElements()) {
            java.net.NetworkInterface item = system.nextElement();
            byName.put(item.getName(), item);
        }
        for (Network network : connectivity.getAllNetworks()) {
            LinkProperties links = connectivity.getLinkProperties(network);
            NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
            if (links == null || caps == null || links.getInterfaceName() == null) continue;
            java.net.NetworkInterface systemInterface = byName.get(links.getInterfaceName());
            if (systemInterface == null || systemInterface.isLoopback() || systemInterface.getName().startsWith("tun")) continue;
            NetworkInterface item = new NetworkInterface();
            item.setName(systemInterface.getName());
            item.setIndex(systemInterface.getIndex());
            try { item.setMTU(systemInterface.getMTU()); } catch (Exception ignored) { item.setMTU(1500); }
            java.util.ArrayList<String> addresses = new java.util.ArrayList<>();
            for (InterfaceAddress address : systemInterface.getInterfaceAddresses()) {
                if (address.getAddress() != null) {
                    String host = address.getAddress().getHostAddress();
                    int zone = host.indexOf('%');
                    if (zone >= 0) host = host.substring(0, zone);
                    addresses.add(host + "/" + address.getNetworkPrefixLength());
                }
            }
            item.setAddresses(stringIterator(addresses));
            java.util.ArrayList<String> dns = new java.util.ArrayList<>();
            for (InetAddress address : links.getDnsServers()) if (address != null) dns.add(address.getHostAddress());
            item.setDNSServer(stringIterator(dns));
            java.util.ArrayList<String> gateways = new java.util.ArrayList<>();
            for (android.net.RouteInfo route : links.getRoutes()) {
                if (route.getDestination() != null && route.getDestination().getPrefixLength() == 0
                        && route.getGateway() != null && !route.getGateway().isAnyLocalAddress()) {
                    gateways.add(route.getGateway().getHostAddress());
                }
            }
            item.setGateway(stringIterator(gateways));
            int flags = 0;
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) flags |= OsConstants.IFF_UP | OsConstants.IFF_RUNNING;
            if (systemInterface.isPointToPoint()) flags |= OsConstants.IFF_POINTOPOINT;
            if (systemInterface.supportsMulticast()) flags |= OsConstants.IFF_MULTICAST;
            item.setFlags(flags);
            int type = Libbox.InterfaceTypeOther;
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) type = Libbox.InterfaceTypeWIFI;
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) type = Libbox.InterfaceTypeCellular;
            else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) type = Libbox.InterfaceTypeEthernet;
            item.setType(type);
            item.setMetered(!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED));
            result.add(item);
        }
        return networkIterator(result);
    }

    private static NetworkInterfaceIterator networkIterator(java.util.List<NetworkInterface> values) {
        java.util.Iterator<NetworkInterface> iterator = values.iterator();
        return (NetworkInterfaceIterator) Proxy.newProxyInstance(NetworkInterfaceIterator.class.getClassLoader(),
                new Class<?>[]{NetworkInterfaceIterator.class}, (proxy, method, args) -> {
                    if ("hasNext".equals(method.getName())) return iterator.hasNext();
                    if ("next".equals(method.getName())) return iterator.hasNext() ? iterator.next() : null;
                    return null;
                });
    }

    private static StringIterator stringIterator(java.util.List<String> values) {
        java.util.Iterator<String> iterator = values.iterator();
        return (StringIterator) Proxy.newProxyInstance(StringIterator.class.getClassLoader(),
                new Class<?>[]{StringIterator.class}, (proxy, method, args) -> {
                    if ("hasNext".equals(method.getName())) return iterator.hasNext();
                    if ("next".equals(method.getName())) return iterator.hasNext() ? iterator.next() : null;
                    if ("len".equals(method.getName())) return values.size();
                    return null;
                });
    }

    private static boolean hasNext(RoutePrefixIterator iterator) { return iterator != null && iterator.hasNext(); }
    private static boolean addAddressPrefixes(Builder builder, RoutePrefixIterator iterator) throws Exception {
        boolean added = false;
        if (iterator == null) return false;
        while (iterator.hasNext()) {
            RoutePrefix prefix = iterator.next();
            builder.addAddress(prefix.address(), prefix.prefix());
            added = true;
        }
        return added;
    }
    private static boolean addRoutePrefixes(Builder builder, RoutePrefixIterator iterator) throws Exception {
        boolean added = false;
        if (iterator == null) return false;
        while (iterator.hasNext()) {
            RoutePrefix prefix = iterator.next();
            builder.addRoute(prefix.address(), prefix.prefix());
            added = true;
        }
        return added;
    }
    private static void addExcludedRoutes(Builder builder, RoutePrefixIterator iterator) throws Exception {
        if (iterator == null) return;
        while (iterator.hasNext()) {
            RoutePrefix prefix = iterator.next();
            builder.excludeRoute(new IpPrefix(prefix.address(), prefix.prefix()));
        }
    }
    private static void addDnsServers(Builder builder, StringIterator iterator) throws Exception {
        if (iterator == null) return;
        while (iterator.hasNext()) {
            String address = iterator.next();
            if (address != null && !address.trim().isEmpty()) builder.addDnsServer(InetAddress.getByName(address));
        }
    }
    private void addPackages(Builder builder, StringIterator iterator, boolean allowed) throws Exception {
        if (iterator == null) return;
        while (iterator.hasNext()) {
            String packageName = iterator.next();
            if (packageName == null || packageName.trim().isEmpty()) continue;
            if (allowed) builder.addAllowedApplication(packageName); else builder.addDisallowedApplication(packageName);
        }
    }
    private static java.util.List<String> collectStrings(StringIterator iterator) throws Exception {
        java.util.ArrayList<String> values = new java.util.ArrayList<>();
        if (iterator != null) while (iterator.hasNext()) values.add(iterator.next());
        return values;
    }
    /** Safe fallback for optional methods on version-pinned libbox Java interfaces. */
    private static Object primitiveDefault(Class<?> type) {
        if (!type.isPrimitive() || type == Void.TYPE) return null;
        if (type == Boolean.TYPE) return false;
        if (type == Character.TYPE) return '\0';
        if (type == Byte.TYPE) return (byte) 0;
        if (type == Short.TYPE) return (short) 0;
        if (type == Integer.TYPE) return 0;
        if (type == Long.TYPE) return 0L;
        if (type == Float.TYPE) return 0F;
        if (type == Double.TYPE) return 0D;
        return null;
    }

    private static Object emptyIterator(Class<?> type) {
        return Proxy.newProxyInstance(type.getClassLoader(), new Class<?>[]{type}, (proxy, method, args) -> {
            if ("hasNext".equals(method.getName())) return false;
            if ("next".equals(method.getName())) return null;
            if ("toString".equals(method.getName())) return "EmptyIterator";
            return null;
        });
    }

    private void stopEngine() { stopEngineInternal(true); }
    private synchronized void stopEngineInternal(boolean publish) {
        if (stopping && commandServer == null && tunDescriptor == null) return;
        stopping = true;
        CommandServer server = commandServer;
        commandServer = null;
        if (server != null) {
            try { server.closeService(); } catch (Exception e) { Log.w(TAG, "closeService", e); }
            try { server.close(); } catch (Exception e) { Log.w(TAG, "close", e); }
        }
        ParcelFileDescriptor descriptor = tunDescriptor;
        tunDescriptor = null;
        if (descriptor != null) try { descriptor.close(); } catch (Exception e) { Log.w(TAG, "close TUN", e); }
        closeDefaultInterfaceMonitor();
        platformInterface = null;
        commandHandler = null;
        activeConfig = null;
        if (publish) {
            stopForeground(true);
            publishState("DISCONNECTED", null);
            stopSelf();
        }
    }

    private void startForegroundCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID,
                    "VPN connection", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, TunnelVpnService.class).setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent disconnect = PendingIntent.getService(this, 1, stop, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("Mahmoud Tunnel")
                .setContentText("Starting secure tunnel…").setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", disconnect);
        startForeground(NOTIFICATION_ID, builder.build());
    }
    private void updateNotification(String message) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        Intent stop = new Intent(this, TunnelVpnService.class).setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent disconnect = PendingIntent.getService(this, 1, stop, flags);
        builder.setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("Mahmoud Tunnel")
                .setContentText(message).setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", disconnect);
        manager.notify(NOTIFICATION_ID, builder.build());
    }
    private void publishState(String state, String error) {
        Intent update = new Intent(ACTION_STATE).setPackage(getPackageName()).putExtra(EXTRA_STATE, state);
        if (error != null) update.putExtra(EXTRA_ERROR, error);
        sendBroadcast(update);
    }
    private static String safeMessage(Throwable error) {
        String message = error == null ? null : error.getMessage();
        return message == null || message.trim().isEmpty() ? "VPN engine could not start" : message;
    }
    @Override public void onRevoke() { engineExecutor.execute(this::stopEngine); super.onRevoke(); }
    @Override public void onDestroy() {
        engineExecutor.execute(this::stopEngine);
        engineExecutor.shutdown();
        super.onDestroy();
    }
}
