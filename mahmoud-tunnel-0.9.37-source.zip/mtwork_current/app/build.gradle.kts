plugins { id("com.android.application") }

android {
    namespace = "com.mahmoud.tunnel"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mahmoud.tunnel"
        minSdk = 24
        targetSdk = 35
        versionCode = 48
        versionName = "0.9.37"
    }
}


dependencies {
    // Exact Java binding inspected from the 1.14.4 source archive and used by TunnelVpnService.
    implementation("com.github.singbox-android:libbox:1.14.4")
    testImplementation("junit:junit:4.13.2")
}
