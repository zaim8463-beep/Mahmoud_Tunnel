# libbox Android API verification — 1.14.4

## Exact artifact inspected

The generated Java binding source archive was inspected from the `singbox-android/libbox` **1.14.4** release. The app dependency is pinned to:

```kotlin
implementation("com.github.singbox-android:libbox:1.14.4")
```

The source archive confirms the Java package `io.nekohasekai.libbox` and the following concrete signatures:

- `Libbox.setup(SetupOptions)`
- `Libbox.checkConfig(String)`
- `Libbox.findConnectionOwner(int, String, int, String, int)`
- `new CommandServer(CommandServerHandler, PlatformInterface)`
- `CommandServer.start()`
- `CommandServer.startOrReloadService(String, OverrideOptions)`
- `CommandServer.closeService()` and `CommandServer.close()`
- `PlatformInterface.openTun(TunOptions)` returning an integer file descriptor
- `TunOptions` getters for TUN addresses, route ranges, DNS, MTU, auto-route, packages, and HTTP proxy settings

The source signatures are used by `TunnelVpnService`. Its platform adapter protects engine sockets with `VpnService.protect`, creates the Android TUN interface from the engine-provided `TunOptions`, and returns the established descriptor to libbox. A `CommandServerHandler` proxy handles stop, reload, status, and log callbacks.

## Runtime responsibilities

1. The Activity obtains consent using `VpnService.prepare()` before starting the foreground VPN service.
2. The service initializes libbox once with app-specific base, working, and temporary directories.
3. The complete sing-box JSON is checked by `Libbox.checkConfig` before startup.
4. The command server is started, then `startOrReloadService` starts the actual sing-box service.
5. `CONNECTED` is published only after the start call returns successfully.
6. Stop, revoke, startup failure, and destruction close the command service and the retained duplicate TUN lifecycle handle; libbox owns the detached native descriptor.

## Important limits

- The exact generated binding API is verified against the 1.14.4 source archive; this is not equivalent to a successful Android compilation or a live VPN test.
- The Java platform adapter deliberately uses dynamic proxies for optional `PlatformInterface` methods. Optional shell, bridge, neighbor monitor, Wi-Fi state, and system proxy features are not implemented.
- Network-interface discovery is implemented for the current Android networks, but network transition, sleep/resume, IPv6, DNS, and OEM-specific behavior need real-device testing.
- `CONNECTED` means sing-box accepted and started the configuration and Android established the TUN interface; end-to-end reachability must still be verified against a reachable, authorized server.
- libbox is GPL-3.0 licensed. Review corresponding-source and redistribution requirements before release.

## Upstream sources

- https://github.com/singbox-android/libbox/tree/1.14.4
- https://github.com/singbox-android/libbox/releases/tag/1.14.4
- https://github.com/SagerNet/sing-box-for-android
