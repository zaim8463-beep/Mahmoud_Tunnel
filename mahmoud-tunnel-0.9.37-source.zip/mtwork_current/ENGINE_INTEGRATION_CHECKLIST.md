# Mahmoud Tunnel 0.9.31 — engine integration status

## Implemented in this source snapshot

- Pinned Android binding dependency: `com.github.singbox-android:libbox:1.14.4`.
- A real `VpnService` host using the 1.14.4 generated Java API: `Libbox.setup`, `Libbox.checkConfig`, `CommandServer`, and `startOrReloadService`.
- A `PlatformInterface` adapter that protects sing-box sockets, creates Android TUN descriptors from `TunOptions`, and reports Android network interfaces.
- Foreground service notification with a disconnect action; stop/revoke/destroy cleanup closes the command server and TUN descriptor.
- Android VPN consent flow from the Connect button.
- Share-link conversion for VLESS (TCP/WS/HTTPUpgrade/gRPC and TLS/REALITY), VMess (TCP/WS, alterId=0), Trojan, Shadowsocks, SOCKS, and HTTP/HTTPS proxy profiles.
- Existing full sing-box JSON configurations are passed to libbox for authoritative validation.
- A Debian/Ubuntu server deployment script for one VLESS + REALITY listener. It creates server credentials and writes a client URI to `/root/mahmoud-tunnel-client.txt`.

## Not yet verified / remaining work

- No Android SDK or Gradle executable is present in this workspace, so `assembleDebug`, unit tests, and APK creation were not run here.
- No Android device/emulator test has been run. The app reports CONNECTED only when `startOrReloadService` returns successfully and the Android TUN callback has established an interface; device-level packet routing, DNS, IPv6, sleep/resume, and reconnect still require real-device testing.
- The server script is prepared but has not been run. It requires a Debian/Ubuntu VPS under the operator's control, root access, and inbound TCP access to the selected port. The provider firewall may need a separate rule.
- SSH, OpenVPN, WireGuard text profiles, ShadowsocksR, and other unsupported/legacy formats are not silently converted. Use a sing-box JSON profile or one of the explicitly supported share-link schemes above.
- The platform adapter intentionally does not implement optional shell, bridge, neighbor-table, per-app process-owner, or system-proxy features.
- The project uses GPL-3.0-licensed libbox. Review and satisfy source-distribution and license obligations before distributing the combined application.

## Device validation sequence

1. Build and install the debug APK with Android SDK 35 / JDK 17 / Gradle 8.9.
2. Import a known-good VLESS REALITY or VMess/TLS profile for a server you control.
3. Grant Android VPN consent and connect; verify the persistent notification and Android VPN key icon.
4. Check public egress IP, DNS resolution, IPv4/IPv6 routing, and traffic counters from an external test endpoint.
5. Disconnect from the notification and verify the TUN interface and foreground service are released.
6. Repeat with Wi-Fi/cellular transitions, screen-off, and process recreation.

## Follow-up hardening pass (2026-11-18)

- Hardened both dynamic libbox proxy adapters so optional interface methods that return Java primitives receive type-safe defaults rather than `null` (which could trigger unboxing `NullPointerException`).
- Static source checks confirm the startup path includes libbox setup, `checkConfig`, command-server start, Android TUN establishment, socket protection, and failure cleanup.
- This is source-level validation only. It does not replace compilation against the Android SDK, libbox runtime testing, or an end-to-end connection test.


## 0.9.35 descriptor ownership correction (2026-11-18)

- `openTun()` now calls `ParcelFileDescriptor.detachFd()` before returning the native descriptor to libbox.
- A duplicated `ParcelFileDescriptor` is retained as a lifecycle handle and closed only after the command service is stopped, avoiding Java closing the exact descriptor owned by native sing-box.
- CONNECTED is no longer broadcast from inside `openTun()`; the state is published after `startOrReloadService()` returns and the TUN lifecycle handle exists.
- Static source assertions and shell syntax checks pass. Android compilation and real-device tests remain pending.
