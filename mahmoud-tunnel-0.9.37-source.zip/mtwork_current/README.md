# Mahmoud Tunnel — Android client foundation

Current source version: **0.9.35 (TUN descriptor handoff and connection-state hardening — not yet device-verified)**

## 0.9.35 — native TUN descriptor ownership and lifecycle hardening

- Transfers the Android VPN descriptor to native sing-box with `detachFd()` and retains a duplicate only for controlled lifecycle cleanup.
- Reports CONNECTED only after sing-box has accepted the config and the Android TUN interface was established.
- Surfaces STARTING in the UI and resets pending config when VPN permission is denied.
- Android versionCode is 46. This remains source-level work and is not yet device-verified.

## 0.9.34 — direct share-link import and server setup hardening

- Adds a paste-share-link action so a user can import a VLESS/Trojan/Shadowsocks/VMess/SOCKS/HTTP link directly without first creating a text file.
- Updates the app preview label and subscription User-Agent to 0.9.34; Android versionCode is 45.
- Updates the Debian/Ubuntu server setup script to install sing-box from its official signed APT repository, install prerequisites, and validate the installed configuration.
- The server script still requires a VPS owned or administered by the user; it does not provision cloud infrastructure or supply a public server.
- **Not yet verified:** no Android SDK/Gradle build, APK, device-level VPN traffic test, or live server deployment has been completed.

## 0.9.31 — libbox engine and server foundation

- Adds a version-pinned `libbox` 1.14.4 runtime path using the generated `PlatformInterface`, `CommandServer`, and `Libbox.checkConfig` APIs.
- Connect flow now requests Android VPN consent, establishes the TUN descriptor from libbox `TunOptions`, protects engine sockets, starts the sing-box service, and exposes a foreground disconnect action.
- Adds profile-to-sing-box JSON conversion for VLESS (TCP/WS/HTTPUpgrade/gRPC, TLS/REALITY), VMess (TCP/WS, alterId 0), Trojan, Shadowsocks, SOCKS, HTTP/HTTPS, and complete sing-box JSON.
- Adds `server/deploy-vless-reality.sh` for an operator-owned Debian/Ubuntu VPS; it generates a VLESS REALITY listener and a private client URI file.
- **Not yet verified:** this workspace has no Android SDK or Gradle executable. No Gradle build, unit tests, APK, device-level packet test, or live server deployment has been completed. SSH/OpenVPN/WireGuard text profiles and legacy/unsupported transports are not converted by this adapter.



## 0.9.29 — profile management usability

- Adds a safe rename flow for imported configurations, preserving the original configuration bytes and rolling back the in-memory name if secure storage fails.
- Adds a details summary that shows protocol and payload size without exposing server credentials in the dialog.
- Requires confirmation before removing a saved profile and restores the profile if the encrypted-store write fails.
- Adds a shared profile-name normalizer with control-character and path-separator removal and a 42-character limit, plus regression tests.
- Updates preview text, subscription User-Agent, and Android versionName/versionCode to 0.9.29 / 41.
- This is profile-manager functionality, not a VPN engine integration. No production sing-box adapter, Android VpnService, configured server, live tunnel, or APK build is claimed.

## 0.9.28 — strict subscription payload decoding

- Subscription downloads now use a bounded UTF-8 decoder that rejects malformed byte sequences instead of silently replacing invalid bytes.
- UTF-8 BOM is removed safely before parsing; the existing 1 MiB response limit is enforced again at the decoder boundary.
- Added regression tests for malformed UTF-8, null and oversized payloads, and BOM handling.
- Updated preview text, subscription User-Agent, and Android versionCode to 40.
- This improves downloaded payload handling only. DNS answers are not pinned, and no production VPN engine, authorized server, live tunnel, or APK build is claimed.

## 0.9.27 — IPv6 special-range validation

- Tightened subscription URL checks to accept only IPv6 global-unicast space and reject documentation, transition, and other non-global ranges.
- Expanded IPv4 reserved/documentation-range regression coverage and retained rejection of legacy numeric host spellings.
- Added tests for IPv6 documentation, 6to4, and documentation prefixes.
- Updated preview text, subscription User-Agent, and Android versionCode to 39.
- This is URL input hardening only. Hostname DNS resolution is not pinned to validated addresses, so it is not a complete defense against DNS rebinding; no VPN engine, configured server, live tunnel, or APK build is claimed.

## 0.9.26 — legacy numeric host rejection

- Rejects ambiguous numeric host spellings such as shortened IPv4, single-integer IPv4, octal, and hexadecimal forms before subscription requests.
- Rejects additional IPv4 documentation/reserved ranges (192.0.2.0/24, 198.51.100.0/24, and 203.0.113.0/24), alongside the existing local/private checks.
- Added regression tests for the alternate host spellings and reserved ranges.
- Updated Android versionCode to 38 and the displayed app/User-Agent version to 0.9.26.
- This is URL validation hardening only. DNS rebinding is not fully mitigated, and no production VPN engine, authorized server, or APK build is claimed.

## 0.9.25 — subscription target validation

- Subscription URL validation now rejects localhost, local-only host suffixes, and private, loopback, link-local, multicast, and reserved IPv4 targets before a request is made.
- IPv6 literals are checked without performing DNS lookups; ordinary provider hostnames remain eligible.
- Added regression cases for local router and cloud-metadata-style addresses.
- Updated preview text, subscription User-Agent, and Android versionCode to 37.
- This is subscription-fetch hardening only; the native VPN engine integration remains unimplemented and no APK or live tunnel is claimed.

## 0.9.24 — encrypted profile envelope bounds

- Added a pre-decode size cap for the encrypted profile preference value to avoid allocating an unbounded Base64-decoded buffer.
- Validate the AES-GCM envelope nonce length and minimum authentication-tag/ciphertext size before attempting decryption.
- Added regression tests for encoded-length limits and malformed envelopes.
- Updated preview text, subscription User-Agent, and Android versionCode to 36.
- This is local-storage hardening only; no production libbox adapter, Android `VpnService`, configured server, live tunnel, or APK build is claimed.

## 0.9.23 — subscription lifecycle guard fix

- Fixed a missed lifecycle transition: the previous version checked whether the Activity was destroyed, but never set that flag in `onDestroy()`.
- Added a small thread-safe `ActivityLifecycleGate`, marked destroyed before the subscription executor is shut down; queued UI callbacks now consult the same tested guard.
- Added regression tests for active, destroyed, and repeated-destruction states.
- Updated preview text, subscription User-Agent, and Android versionCode to 35.
- This is lifecycle hardening only; it does not add a production libbox adapter, Android `VpnService`, configured server, live tunnel, or APK build.

## 0.9.22 — subscription lifecycle safety

- Prevented queued subscription download callbacks from updating UI or importing profiles after the Activity has been destroyed.
- Kept cancellation explicit by marking the Activity destroyed before shutting down its subscription executor.
- Updated the subscription User-Agent and displayed preview version to 0.9.22; Android versionCode is 34.
- This is an Activity lifecycle hardening change only; no production libbox adapter, Android `VpnService`, configured server, live tunnel, or APK build is claimed.

## 0.9.21 — validated profile restore

- Restored share-link records now pass the same protocol-specific structural validator used for new imports, instead of being accepted solely because the protocol label matches.
- Added regression tests for malformed VLESS/Trojan records and valid WireGuard/Hysteria2 aliases.
- Multiline WireGuard/OpenVPN files and JSON outbound profiles remain on their dedicated validation paths.
- This hardens local data restoration only; it does not validate a complete engine runtime configuration or establish a VPN tunnel.
- No production libbox adapter, Android `VpnService`, configured server, live tunnel, or APK build is claimed.

## 0.9.20 — bounded alias link validation

- Applied the 64 KiB input bound consistently to alternate share-link schemes (`wg://`, `hy2://`, SOCKS aliases, and HTTP proxy schemes) before URI parsing.
- Added regression coverage for oversized alias inputs, blank alias values, and HTTP proxy port boundaries.
- This is parser hardening only; share-link recognition is not equivalent to validating a complete engine configuration.
- No production libbox adapter, Android `VpnService`, configured server, live tunnel, or APK build is claimed.

## 0.9.19 — observer failure isolation

- Isolated runtime exceptions thrown by UI state/error listeners so presentation-layer failures cannot interrupt engine start/stop calls or corrupt the authoritative lifecycle state.
- Added regression tests for throwing state and error listeners.
- Kept callback invocation outside the coordinator monitor.
- Java lifecycle smoke checks were run; full Gradle/JUnit and APK builds remain unavailable in this workspace.
- No production libbox adapter, Android `VpnService`, configured server, or live tunnel is claimed.

## 0.9.18 — VPN lifecycle callback isolation

- Refactored `VpnEngineCoordinator` so application-provided state listeners are invoked after releasing the coordinator monitor. This avoids holding the lifecycle lock while arbitrary UI/application callbacks run.
- Kept state transitions and operation-id checks synchronized; stale engine callbacks remain ignored.
- Updated the displayed preview version, subscription User-Agent, and Android versionCode to 30.
- Added a regression test proving a listener can hand state inspection to another thread without blocking on the coordinator lock.
- Java-only lifecycle compilation and smoke checks can run locally; Android Gradle/JUnit and APK builds remain unavailable in this workspace.
- No production libbox adapter, Android `VpnService`, configured server, or live tunnel is claimed.

## 0.9.17 — native integration research checkpoint

- Recovered and inspected the saved 0.9.16 project archive; corrected the README version header, which incorrectly still said 0.9.15.
- Inspected the upstream sing-box-for-android service implementation to identify the real integration surface: `Libbox.setup`/application setup, `CommandServer`, `CommandServerHandler`, `PlatformInterface`, and `TunOptions`-driven `VpnService.Builder.establish()` flow.
- Recorded the source files and compatibility caveat in `ENGINE_API_RESEARCH.md`. The inspected app branch is `dev`, not a pinned source revision proven to match libbox 1.14.4, so these signatures are research leads only and have not been copied into production code.
- No VPN service or engine adapter is claimed in this checkpoint.

## Implemented
- Native Android Java application shell.
- Local profile list persisted in app-private SharedPreferences.
- Document-picker import for text and JSON files.
- HTTPS subscription URL import on a background executor, with connection/read timeouts, redirects disabled, and a strict 1 MiB response cap.
- Base64 subscription decoding when the decoded payload contains recognizable profile text.
- Recognition of VLESS, VMess, Trojan, WireGuard, SSH, Shadowsocks, Hysteria, Hysteria 2, TUIC, AnyTLS, ShadowTLS, and SOCKS share-link markers.
- Structural recognition of matching sing-box JSON outbound types, including HTTP proxy outbounds.
- Import of multiple supported links from a text subscription export, skipping blank/comment/unrelated lines.
- Duplicate profile suppression and a 1 MB import-size guard.
- Local profile search by name/protocol.
- A 100-profile safety limit and clearer empty-search state.

- Subscription downloads require an explicit HTTPS URL supplied by the user; no third-party subscriptions or servers are bundled.

## Not implemented / not represented as working
- No VPN tunnel engine is bundled or connected yet.
- No `VpnService` connection lifecycle exists yet.
- No production server fleet, user authentication, subscription backend, billing, or admin panel exists yet.
- The UI intentionally does not pretend that selecting a profile creates a VPN connection.

## Engine integration decision
The leading candidate is the Android `libbox` binding for sing-box. The official sing-box Android documentation describes using Android `VpnService` for TUN operation and supports a broad set of outbound protocols. The Android binding is distributed separately as an AAR. Before shipping it, review the exact version's API and GPL-3.0-or-later obligations; distributing a combined app with this engine may require publishing corresponding source under a GPL-compatible license and preserving notices. Do not copy the SFA app or use its name/branding.

References:
- https://sing-box.sagernet.org/clients/android/features/
- https://github.com/singbox-android/libbox
- https://github.com/SagerNet/sing-box-for-android

## Build status
This workspace currently has no Android SDK, Gradle executable, or configured signing key. Therefore an APK has **not** been built or tested. Build with Android Studio / Android Gradle Plugin after installing the required SDK. The project uses compileSdk 35 and minSdk 24.

## Next engineering milestones
1. Pin a reviewed libbox AAR version and integrate its documented Android service API.
2. Add a foreground `VpnService` with explicit user consent, lifecycle handling, notifications, and safe stop/reconnect behavior.
3. Convert supported share links into validated sing-box JSON using a maintained parser; reject unsupported/incomplete profiles with clear errors.
4. Add tests for parsers and configuration validation.
5. Deploy only authorized servers, then implement authenticated profile delivery and subscription expiry.
6. Build signed APK/AAB and test on physical Android devices and multiple network conditions.

## Security
Treat imported profiles as untrusted input. Never log credentials, private keys, or full profile URIs. Only connect to servers you own or are authorized to use.


## Preview 0.5.0 security update

- Profile data is now encrypted at rest with AES-256/GCM using a non-exportable Android Keystore key.
- Existing plaintext profile stores are migrated to encrypted storage on the next successful load.
- Import remains limited to 1 MiB per file and 100 stored profiles.
- This preview still does not include a VPN tunnel engine or server-side service. The app must not advertise a working VPN connection until an authorized server and a tested engine integration are added.


## Preview 0.5.1 hardening update

- Enforce the 1 MiB import limit during streaming reads, before the full document is accumulated in memory.
- Keep the saved-profile counter accurate when the library is empty.
- No tunnel engine or production server is included in this update.


## Preview 0.6.0

- Recognize sing-box JSON profiles by parsing the root/outbounds structure rather than substring matching.
- Avoid misclassifying arbitrary JSON containing an `interface` field as WireGuard.
- Limit a single JSON profile to 256 KiB and the total stored profile payload to 2 MiB.
- These are import/storage safeguards only; profile syntax is not yet fully validated by sing-box and no VPN connection is implemented.


## Preview 0.7.0 — safer batch import

- Imports are staged and validated before modifying the saved profile list.
- Duplicate profiles already in the library are skipped.
- Per-profile, total-storage, and profile-count limits are checked before commit.
- A failed validation no longer leaves partially imported entries in the in-memory list.

This is still a profile manager preview. It does not include a working VPN tunnel engine,
server infrastructure, account backend, or a verified APK. Do not use imported profiles
unless you own them or have permission to use them.

## 0.7.1 storage reliability update

- Profile deletion is now transactional from the UI's perspective: if encrypted persistence fails, the removed profile and previous selection are restored.
- Encrypted profile writes use `SharedPreferences.commit()` so the caller receives the disk-write result instead of assuming an asynchronous `apply()` succeeded.
- This is a source-level change; it has not been compiled or exercised on an Android device in this environment.

## Current connectivity status

The source now contains a libbox 1.14.4 engine startup path, Android `VpnService` TUN adapter, VPN consent flow, and VLESS REALITY server deployment script. However, these changes have not been compiled or tested on an Android device in this workspace, and no server has been deployed. Do not treat the app as production-ready until the debug build, device-level traffic/DNS tests, disconnect/reconnect tests, and a live connection to an authorized server all pass.


## 0.8.0 profile recognition update

The local profile importer now recognizes additional sing-box-compatible share-link schemes: Shadowsocks (`ss://`), Hysteria (`hysteria://`), Hysteria 2 (`hysteria2://` / `hy2://`), TUIC (`tuic://`), AnyTLS (`anytls://`), ShadowTLS (`shadowtls://`), and SOCKS (`socks://`, `socks5://`, `socks5h://`). JSON outbounds are also classified for these protocol types, including HTTP proxy outbounds. Recognition is not validation: imported profiles still require a compatible engine and reachable, authorized server before they can connect.


## 0.8.2 — reproducible Android build pipeline

- Added a GitHub Actions workflow that installs JDK 17, Gradle 8.9, Android SDK Platform 35, and Build Tools 35.0.0, then runs `gradle assembleDebug`.
- The workflow uploads the generated debug APK as the `mahmoud-tunnel-debug-apk` artifact on successful pushes, pull requests, or manual runs.
- Added standard Android/Gradle build outputs to `.gitignore`.
- Incremented Android versionCode to 10 and versionName to 0.8.2.

### Build using the workflow

1. Create a GitHub repository and upload this project source.
2. Push the source to the repository's default branch.
3. Open the repository's Actions tab and wait for **Android debug build** to finish.
4. Download the `mahmoud-tunnel-debug-apk` artifact from the successful workflow run.

This workflow has been authored but cannot be executed from this workspace: network access is unavailable and the Android SDK/Gradle are not installed here. A successful CI run is still required before treating any APK as build-verified. The resulting debug APK is for testing; a release APK/AAB requires a user-controlled signing key and a separate release process.


## 0.8.2 engineering update

- Extracted share-link / sing-box JSON protocol detection into `ProfileProtocolDetector` so it can be tested independently of the Activity UI.
- Added JVM unit tests for supported URI schemes and rejection of unknown/subscription URLs.
- CI now runs `testDebugUnitTest` before attempting the debug APK build.
- This release still does **not** include a VPN engine or server. The UI must not represent an imported profile as connected.


## 0.9.0 — HTTPS subscription import

- Added an in-app subscription URL prompt and HTTPS-only download path.
- Downloads run off the UI thread, use finite connect/read timeouts, do not follow redirects, and stop after 1 MiB.
- Supports plain-text subscription payloads and Base64-wrapped payloads when the decoded text looks like supported profile content.
- Added the Android `INTERNET` permission and incremented versionCode to 12.
- This imports profiles only. It does not validate server reachability, provide server access, or connect a VPN.

The new network-import code has not yet been compiled by Android Gradle Plugin or tested on a physical device in this workspace. The CI workflow remains the required APK build verification path.


## 0.9.1 — HTTP proxy recognition hardening

- Recognizes explicit HTTP/HTTPS proxy share URIs only when they include a username/password, a host, an explicit port, and no meaningful URL path.
- Keeps ordinary HTTPS subscription URLs and normal website URLs classified as unknown instead of treating them as proxy profiles.
- Adds SOCKS4 recognition alongside SOCKS, SOCKS5, and SOCKS5h.
- Adds regression unit cases for proxy links, ordinary web URLs, paths, whitespace, and mixed-case schemes.
- Increments Android versionCode to 13 and versionName to 0.9.1.

This is profile recognition only. It does not validate proxy credentials or establish a VPN tunnel. The Android Gradle tests/build have not been run in this workspace.


## 0.9.2 — VPN lifecycle foundation

- Added a UI-independent connection state machine with explicit `IDLE`, `PREPARING`, `CONNECTED`, `STOPPING`, and `FAILED` states.
- Rejects illegal transitions so a future engine adapter cannot report `CONNECTED` before preparation or stop before a connection exists.
- Added JVM tests for successful connect/disconnect, failure recovery, null input, and illegal transitions.

This is lifecycle groundwork only. No libbox binding, Android `VpnService`, tunnel traffic, or server is connected in this release. The new JUnit tests have been authored but could not be run here because Gradle and the Android SDK are unavailable.


## 0.9.3 — multi-line VPN profile import

- Recognizes complete OpenVPN client profiles using the `client`, `dev tun`, and `remote` directives.
- Recognizes multi-line WireGuard configuration files by checking for interface/peer sections and required key/endpoint fields, including files with leading comments.
- Imports a recognized multi-line WireGuard or OpenVPN document as one complete profile instead of splitting it into individual lines.
- Keeps plain-text subscription exports as line-by-line batches and retains duplicate/size/profile-count safeguards.

This is import-format recognition only. No OpenVPN or WireGuard tunnel engine is connected in this preview, and no VPN connection is claimed.

## 0.9.4 — mixed subscription parsing
- Adds a standalone profile import parser that can preserve a multiline WireGuard or OpenVPN document while extracting supported one-link-per-line entries from the same subscription text.
- Adds unit tests for multiline preservation, mixed subscriptions, unsupported text, and null input.
- A local Java smoke harness passed for mixed VLESS + WireGuard + Trojan imports, standalone OpenVPN documents, and multiple share links. Android Gradle/JUnit tests and APK assembly remain unrun because this environment has no Gradle executable or Android SDK.
- This remains profile import only: it does not establish a VPN tunnel or validate that imported credentials/servers are operational.


## 0.9.5 — import compatibility and lifecycle cleanup

- Handles UTF-8 byte-order marks at the start of imported profiles.
- Accepts LF, CRLF, and classic CR line endings when detecting and parsing multi-line WireGuard/OpenVPN profiles and line-based subscriptions.
- Adds regression tests for BOM-prefixed files and classic-Mac line endings.
- Removes an unnecessary persisted document-provider URI permission because imported files are read immediately and are not accessed later.
- Shuts down the subscription-download executor when the Activity is destroyed, avoiding a worker lingering beyond its screen lifecycle.
- Increments versionCode to 17 and versionName to 0.9.5.

A local Java smoke harness passed for BOM-prefixed WireGuard, CR-delimited OpenVPN, mixed CR-delimited share links, and the connection state-machine lifecycle. This is not an Android Gradle build or a live VPN test. The project still has no embedded VPN engine, configured server, or installable APK produced by this workspace.

## 0.9.7 — share-link structural validation

- Adds conservative URI structure checks before individual share links are saved: expected scheme, host, valid port range, and required user information for protocols that use it.
- Supports common aliases including `hy2://`, `wg://`, and SOCKS variants.
- Rejects malformed links instead of saving entries that only happen to begin with a recognized scheme.
- Adds regression tests for malformed links and mixed subscriptions containing both valid and invalid entries.
- Updates the subscription User-Agent and app version to 0.9.7 (versionCode 18).

These checks only validate basic URI structure. They do not validate credentials, cryptographic settings, server reachability, full sing-box configuration semantics, or establish a VPN tunnel. The libbox engine, Android VpnService integration, authorized servers, and verified APK are still outstanding.


## 0.9.7
- Added export of an individual imported profile through Android Storage Access Framework.
- Suggested export names are sanitized and use `.ovpn` for OpenVPN and `.conf` for WireGuard.
- Export preserves the original UTF-8 profile content without rewriting credentials or formatting.

## 0.9.8 — real-engine adapter boundary
- Added a typed `VpnEngine` contract for a future native backend, including explicit start/stop callbacks.
- Added `VpnEngineCoordinator` to own the connect/disconnect lifecycle and reject overlapping or invalid operations.
- The coordinator enters `CONNECTED` only after the injected backend calls `onConnected`; it returns to `IDLE` only after the backend confirms `onStopped`.
- Stale callbacks from earlier operations are ignored, and backend failures move the lifecycle to `FAILED`.
- Added coordinator unit tests for confirmed connection, confirmed disconnection, startup failure, stale callbacks, and missing engine rejection.

Important: this is an integration boundary, not the sing-box/libbox implementation. No production `VpnEngine` implementation is bundled or injected into the app yet, and the UI remains explicitly disconnected. The official libbox API and Android platform contract must be verified before writing the native adapter; guessing those signatures would risk a broken or misleading VPN implementation. No Android Gradle build, APK, or live tunnel test has been completed in this workspace.


## 0.9.9 — libbox dependency groundwork

- Declares the official `com.github.singbox-android:libbox:1.14.4` Android binding dependency and adds JitPack to dependency resolution. The upstream wrapper's Gradle metadata identifies 1.14.4 as its current published version.
- Adds a third-party notice identifying the upstream GPL-3.0 license and reminding maintainers to satisfy corresponding-source obligations before distribution.
- Updates the app version and subscription User-Agent to 0.9.9.

This is dependency wiring only, not a working engine integration. No libbox classes are called yet; the native API and `PlatformInterface` still need to be matched to the exact resolved AAR before implementing the adapter and Android `VpnService`. Dependency resolution, Gradle tests, APK assembly, and live tunnel operation have not been verified in this workspace.


## 0.9.10 — integration readiness and release gates

- Corrects the top-level project status so it reflects the latest 0.9.9 dependency-groundwork state rather than the stale 0.9.2 heading.
- Updates the app version and subscription User-Agent to 0.9.10 (versionCode 22).
- Adds an explicit acceptance checklist for the next native-engine milestone.
- No engine API calls, Android `VpnService`, server endpoints, or connection behavior are added in this release.

### Required verification before engine code is merged

1. Resolve the exact `libbox:1.14.4` artifact in a clean Android Gradle build and record its checksum and license metadata.
2. Inspect the resolved AAR/source API for the exact Java/Kotlin entry points, callback threading, lifecycle, and `PlatformInterface` contract.
3. Implement a foreground Android `VpnService` with user consent, notification channel, stop action, and process-death handling.
4. Connect the TUN file descriptor and platform callbacks using only signatures verified from that artifact.
5. Validate generated sing-box JSON with the engine's own parser before startup; never pass share links directly as engine configuration.
6. Test permission denial, invalid config, unreachable server, successful tunnel, DNS, traffic routing, stop, and restart on a physical device.
7. Confirm GPL-3.0 compliance and publish the corresponding source/notices required for distribution.

A dependency declaration is not proof that the artifact resolves. This workspace still has no Android SDK or Gradle installation, so dependency resolution, Gradle/JUnit tests, APK assembly, and live VPN tests have not been run here.


## 0.9.11 — subscription URL validation hardening

- Extracts HTTPS subscription URL checks into a small independently testable validator.
- Rejects non-HTTPS URLs, missing hosts, invalid ports, embedded credentials, fragments, whitespace, and control characters before network access.
- Keeps redirects disabled and retains the 1 MiB response limit.
- Adds JUnit coverage for accepted and rejected URL shapes.
- Updates Android versionCode to 23 and versionName to 0.9.11.

**Verification note:** unit tests are added but have not been executed in this environment because the Android/Gradle toolchain is unavailable. This does not implement or claim a working VPN tunnel.


## 0.9.12 — VMess import validation

- VMess share links are no longer accepted merely because their Base64 payload is non-empty.
- The importer now checks Base64 syntax, decoded JSON shape, and the required `add`, `port`, and `id` fields with a valid TCP/UDP port range.
- Added regression cases for malformed Base64, incomplete JSON, and out-of-range ports.
- Kept the decoder compatible with the app's minSdk 24 without relying on newer Android Base64 APIs.

This is still structural import validation only; it does not authenticate a VMess server, validate credentials against a server, or establish a VPN tunnel. Android Gradle/JUnit and APK build remain unrun in this workspace.


## 0.9.13 — strict VMess JSON validation

- Replaces regex-based VMess field extraction with a bounded JSON parser that reads only direct top-level fields and validates the complete JSON document.
- Rejects malformed UTF-8 instead of silently replacing invalid byte sequences.
- Adds decoded-payload and total-link size limits to bound parser work on untrusted imports.
- Preserves support for VMess string or numeric port fields and adds regression tests for nested-field spoofing and trailing garbage.

This remains import validation, not full sing-box config validation or a live VPN connection. Android Gradle/JUnit execution and APK assembly are still not available in this workspace.


## 0.9.14 — bounded and unambiguous VMess parsing

- Rejects duplicate keys in the VMess JSON root object, avoiding ambiguous server identity/endpoint fields.
- Caps nested JSON value depth at 64 levels to prevent stack exhaustion from hostile import payloads.
- Adds regression tests for duplicate root keys and excessive nesting.
- Updates Android versionCode to 26 and versionName to 0.9.14.

**Verification note:** the validator was compiled and exercised with standalone JVM smoke checks. The Android Gradle/JUnit suite, APK assembly, libbox integration, and live VPN tunnel remain unverified/not implemented in this workspace.


## 0.9.15 — stricter VMess payload validation

- Reject VMess `add` values that look like URLs, paths, authorities, or malformed dotted hostnames.
- Bound VMess ID length and reject whitespace/control characters in IDs.
- Reject duplicate keys in nested JSON objects as well as duplicate top-level keys, avoiding ambiguous parser behavior.
- Added regression tests for URL-like hosts and duplicate nested keys.
- Updates Android versionCode to 27 and versionName to 0.9.15.

These checks are import hygiene only. They do not prove that a profile is supported by sing-box or that its server is reachable. The app still has no connected VPN engine or built APK.

## 0.9.16 — saved-profile integrity checks

- Adds a fail-closed validator for profiles restored from local encrypted or legacy storage.
- Checks supported protocol names against the detected content, non-empty bounded profile values, safe bounded display names, duplicate entries, maximum profile count, and aggregate storage size before restoring a saved batch.
- Sanitizes control characters from imported display names before saving.
- Adds unit tests for valid records, protocol mismatch, unsafe names, oversized profiles, duplicate records, empty batches, and profile-count limits.
- Updates the app version and subscription User-Agent to 0.9.16 (versionCode 28).

This improves local profile-store integrity only. It does not add the sing-box runtime, Android VpnService, a configured VPN server, a built APK, or a live tunnel. Android Gradle/JUnit execution remains pending an environment with Gradle and the Android SDK.

## 0.9.30 — Android VPN service foundation
- Adds a declared Android `VpnService` with a TUN-interface establishment helper, socket-protection hook, foreground notification, and stop/revoke cleanup.
- This 0.9.30 checkpoint was platform scaffolding only; the libbox adapter, config conversion, and consent UI are added in 0.9.31.
- Updates Android version to 0.9.30 / versionCode 42.
