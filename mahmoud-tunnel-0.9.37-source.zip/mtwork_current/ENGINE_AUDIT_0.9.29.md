# Mahmoud Tunnel 0.9.29 — source audit (2026-11-18)

## Verified from the uploaded archive

- The archive is a valid ZIP containing 54 entries; extraction completed without errors.
- Android application ID: `com.mahmoud.tunnel`; namespace: `com.mahmoud.tunnel`.
- `minSdk = 24`, `targetSdk = 35`, `compileSdk = 35`.
- The app declares `com.github.singbox-android:libbox:1.14.4` through JitPack.
- The main screen is a local profile manager: import configuration, import HTTPS subscription, search, rename, inspect summary, export, and remove profiles.
- Profile storage is encrypted and the source includes protocol/link/storage validators and unit-test source files.

## Critical runtime gaps — no claims of a working VPN

- `AndroidManifest.xml` declares no `VpnService` service component and no `BIND_VPN_SERVICE` service declaration.
- `VpnEngine.java` is only an interface contract. `VpnEngineCoordinator.java` coordinates an injected implementation, but no production implementation is present in the archive.
- `MainActivity` explicitly displays `VPN ENGINE NOT INSTALLED` and says connecting is unavailable until a real engine and authorized server are configured.
- There are no bundled server endpoints, credentials, or subscription belonging to the app owner.
- Therefore this source cannot establish a VPN tunnel or provide internet traffic through a server in its current state.

## Build verification in this workspace

- Java 21 is present.
- `gradle`, `sdkmanager`, and Android SDK `android.jar` were not found in the inspected environment.
- Consequently no Gradle sync, Android unit-test run, APK assembly, signing, or device test was performed.
- The dependency declaration alone does not verify the generated libbox API or create a tunnel. The exact 1.14.4 source JAR is present upstream, but this workspace cannot retrieve and inspect its binary contents through the available GitHub text fetch interface.

## Required next implementation steps

1. Inspect the exact 1.14.4 source/AAR API and ABI contents; do not copy signatures from a different sing-box release.
2. Implement and declare an Android `VpnService` and a version-matched libbox `PlatformInterface` adapter.
3. Convert supported imported links to validated sing-box JSON using a maintained parser.
4. Add foreground-service lifecycle, VPN consent, TUN descriptor cleanup, notifications, and accurate connection state.
5. Configure at least one server the app owner is authorized to use; no server can be fabricated by the client.
6. Build, run tests, and test actual traffic on a physical Android device; complete GPL-3.0 source/notice obligations before distribution.

**Conclusion:** 0.9.29 is a configuration/profile manager preview, not a functioning VPN client yet. No APK is claimed or included.
