#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVICE="$ROOT/app/src/main/java/com/mahmoud/tunnel/TunnelVpnService.java"
GRADLE="$ROOT/app/build.gradle.kts"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "OK: $*"; }

grep -Fq 'implementation("com.github.singbox-android:libbox:1.14.4")' "$GRADLE" || fail 'libbox dependency is not pinned to 1.14.4'
grep -Fq 'Libbox.setup(createSetupOptions())' "$SERVICE" || fail 'libbox setup call missing'
grep -Fq 'Libbox.checkConfig(config)' "$SERVICE" || fail 'native config validation missing'
grep -Fq 'server.startOrReloadService(config, new OverrideOptions())' "$SERVICE" || fail 'sing-box service start call missing'
grep -Fq 'tunDescriptor = established;' "$SERVICE" || fail 'TUN descriptor ownership missing'
grep -Fq 'return established.getFd();' "$SERVICE" || fail 'native TUN fd return missing'
if grep -Fq 'detachFd()' "$SERVICE"; then fail 'TUN fd must remain owned by ParcelFileDescriptor'; fi
grep -Fq 'registerDefaultNetworkCallback(callback)' "$SERVICE" || fail 'default network callback missing'
grep -Fq 'unregisterNetworkCallback(callback)' "$SERVICE" || fail 'default network callback cleanup missing'
grep -Fq 'android.permission.BIND_VPN_SERVICE' "$MANIFEST" || fail 'VPN service binding permission missing'
grep -Fq 'android:foregroundServiceType="specialUse"' "$MANIFEST" || fail 'VPN foreground service type missing'
bash -n "$ROOT/server/deploy-vless-reality.sh" || fail 'server deployment script syntax invalid'
pass 'libbox lifecycle, TUN ownership, network monitor, manifest, and server script checks'
