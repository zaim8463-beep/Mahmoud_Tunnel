#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: JDK 17 is required." >&2
  exit 2
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 8.9 is required. Install it or use the included GitHub Actions workflow." >&2
  exit 2
fi

java -version 2>&1 | head -n 1
gradle --version | head -n 8
gradle --no-daemon testDebugUnitTest
gradle --no-daemon assembleDebug

echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
