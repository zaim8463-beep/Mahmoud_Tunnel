# Mahmoud Tunnel 0.9.37

## Changes
- Added Android default-network monitoring through `ConnectivityManager.registerDefaultNetworkCallback`.
- Forward default interface name/index changes to sing-box through `InterfaceUpdateListener`, including link-property changes and fallback after network loss.
- Unregister the callback during engine teardown to avoid leaking the service or stale callbacks.
- Retained the upstream-compatible TUN descriptor ownership introduced in 0.9.36.
- Android versionCode: 48.

## Verification status
- Source-level callback signatures and behavior compared with the upstream sing-box Android `DefaultNetworkMonitor` and `VPNService` implementations.
- Shell syntax and ZIP integrity checks completed during packaging.
- Android compilation and live-device/network-switch tests remain unverified: Android SDK/Gradle are not installed in this environment and outbound DNS resolution fails.
- No public server or third-party credentials are bundled.
