# Mahmoud Tunnel server setup

`deploy-vless-reality.sh` installs sing-box on a Debian/Ubuntu VPS and configures one VLESS + REALITY inbound on TCP (default 443).

## Requirements

- A Debian or Ubuntu VPS you own or are authorized to administer.
- Root access and working outbound HTTPS to the official sing-box installer.
- A public IPv4/IPv6 address or DNS name that points to this VPS.
- The selected inbound TCP port allowed in the VPS provider firewall. If UFW is active, the script adds its TCP rule.

## Run

```bash
sudo bash deploy-vless-reality.sh
```

The script backs up an existing `/etc/sing-box/config.json`, generates a UUID and REALITY key pair, validates the configuration with `sing-box check`, and restarts the sing-box systemd service. The client URI is written with mode 0600 to:

```text
/root/mahmoud-tunnel-client.txt
```

That URI contains an access credential. Transfer it privately and do not paste it into public chats or repositories.

## Operations

```bash
sudo systemctl status sing-box
sudo journalctl -u sing-box -f
sudo systemctl restart sing-box
```

The script does not provision a VPS, change SSH access, or guarantee that the provider's network firewall is open. Check the provider firewall separately.
