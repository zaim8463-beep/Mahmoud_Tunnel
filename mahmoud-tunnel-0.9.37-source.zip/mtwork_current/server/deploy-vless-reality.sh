#!/usr/bin/env bash
set -euo pipefail

# Deploys one VLESS + REALITY listener on a Debian/Ubuntu VPS you own or administer.
# It does not open remote shells, create accounts with a cloud provider, or alter SSH.

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run as root: sudo bash deploy-vless-reality.sh" >&2
  exit 1
fi
if [[ ! -r /etc/os-release ]]; then echo "Cannot identify Linux distribution" >&2; exit 1; fi
. /etc/os-release
if [[ "${ID:-}" != "debian" && "${ID:-}" != "ubuntu" ]]; then
  echo "Supported systems: Debian and Ubuntu" >&2; exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "APT is required on supported Debian/Ubuntu systems" >&2
  exit 1
fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ca-certificates curl openssl
command -v systemctl >/dev/null || { echo "systemd is required" >&2; exit 1; }

read -r -p "Public IPv4/IPv6 or DNS name of this VPS: " SERVER
if [[ ! "$SERVER" =~ ^[A-Za-z0-9.-]+$ && ! "$SERVER" =~ ^\[?[0-9A-Fa-f:]+\]?$ ]]; then
  echo "Enter a hostname, IPv4 address, or IPv6 address (without a zone suffix)" >&2
  exit 1
fi
URI_SERVER="$SERVER"
if [[ "$SERVER" == *:* && "$SERVER" != \[*\] ]]; then URI_SERVER="[$SERVER]"; fi
read -r -p "VLESS TCP port [443]: " PORT
PORT=${PORT:-443}
[[ "$PORT" =~ ^[0-9]+$ ]] && (( PORT >= 1 && PORT <= 65535 )) || { echo "Invalid TCP port" >&2; exit 1; }
read -r -p "REALITY handshake SNI [www.microsoft.com]: " SNI
SNI=${SNI:-www.microsoft.com}
[[ "$SNI" =~ ^[A-Za-z0-9.-]+$ ]] || { echo "Invalid SNI hostname" >&2; exit 1; }

if ! command -v sing-box >/dev/null 2>&1; then
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://sing-box.app/gpg.key -o /etc/apt/keyrings/sagernet.asc
  chmod a+r /etc/apt/keyrings/sagernet.asc
  cat > /etc/apt/sources.list.d/sagernet.sources <<'APT_SOURCE'
Types: deb
URIs: https://deb.sagernet.org/
Suites: *
Components: *
Enabled: yes
Signed-By: /etc/apt/keyrings/sagernet.asc
APT_SOURCE
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y sing-box
fi

UUID=$(sing-box generate uuid)
KEYS=$(sing-box generate reality-keypair)
PRIVATE_KEY=$(printf '%s\n' "$KEYS" | sed -nE 's/.*PrivateKey:[[:space:]]*([^[:space:]]+).*/\1/p')
PUBLIC_KEY=$(printf '%s\n' "$KEYS" | sed -nE 's/.*PublicKey:[[:space:]]*([^[:space:]]+).*/\1/p')
if [[ -z "$PRIVATE_KEY" || -z "$PUBLIC_KEY" ]]; then
  echo "Could not parse sing-box reality-keypair output:" >&2
  printf '%s\n' "$KEYS" >&2
  exit 1
fi
SHORT_ID=$(openssl rand -hex 4)

install -d -m 0755 /etc/sing-box
if [[ -f /etc/sing-box/config.json ]]; then
  cp -a /etc/sing-box/config.json "/etc/sing-box/config.json.backup.$(date +%Y%m%d-%H%M%S)"
fi
CONFIG_TMP=$(mktemp)
trap 'rm -f "$CONFIG_TMP"' EXIT
cat > "$CONFIG_TMP" <<JSON
{
  "log": { "level": "info", "timestamp": true },
  "inbounds": [
    {
      "type": "vless",
      "tag": "vless-reality-in",
      "listen": "::",
      "listen_port": ${PORT},
      "users": [{ "uuid": "${UUID}", "flow": "xtls-rprx-vision" }],
      "tls": {
        "enabled": true,
        "server_name": "${SNI}",
        "reality": {
          "enabled": true,
          "handshake": { "server": "${SNI}", "server_port": 443 },
          "private_key": "${PRIVATE_KEY}",
          "short_id": ["${SHORT_ID}"]
        }
      }
    }
  ],
  "outbounds": [{ "type": "direct", "tag": "direct" }]
}
JSON

sing-box check -c "$CONFIG_TMP"
install -m 0600 "$CONFIG_TMP" /etc/sing-box/config.json
sing-box check -c /etc/sing-box/config.json
systemctl enable sing-box
systemctl restart sing-box

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/tcp"
fi

URI="vless://${UUID}@${URI_SERVER}:${PORT}?type=tcp&security=reality&pbk=${PUBLIC_KEY}&fp=chrome&sni=${SNI}&sid=${SHORT_ID}&flow=xtls-rprx-vision#Mahmoud-Tunnel-EU"
OUT="/root/mahmoud-tunnel-client.txt"
umask 077
printf '%s\n' "$URI" > "$OUT"
chmod 0600 "$OUT"

echo
echo "sing-box service status:"
systemctl --no-pager --full status sing-box || true
echo
echo "Client profile saved (contains a private access credential): $OUT"
echo "Copy it securely into Mahmoud Tunnel. Do not post it publicly."
echo "If your VPS provider has a network firewall, allow TCP ${PORT} there too."
