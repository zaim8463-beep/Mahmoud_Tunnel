# Build Mahmoud Tunnel debug APK

This source package does not contain a prebuilt APK. Build it with Android SDK 35, JDK 17, and Gradle 8.9.

## Option A — GitHub Actions

1. Create an empty GitHub repository that you control.
2. Upload/push the complete contents of this folder to the repository's default branch.
3. Open **Actions** and allow workflows if GitHub asks.
4. Run **Android debug build** (or push a commit). The workflow runs unit tests, assembles the debug APK, and uploads `mahmoud-tunnel-debug-apk` as a workflow artifact.
5. Open the successful workflow run, download the artifact, and extract `app-debug.apk`.

## Option B — Android Studio / command line

Open this folder in Android Studio with Android SDK Platform 35 installed. Use JDK 17 and Gradle 8.9, then run:

```bash
gradle --no-daemon testDebugUnitTest
gradle --no-daemon assembleDebug
```

The output is `app/build/outputs/apk/debug/app-debug.apk`.

## Important

A successful APK build only proves compilation and packaging. It does not prove a VPN connection works. Install on a real Android device, import a valid profile for a server you are authorized to use, grant VPN permission, and test routing, DNS, reconnect, and disconnect. The bundled VLESS Reality server script is not deployed automatically; it requires an authorized Debian/Ubuntu VPS.
