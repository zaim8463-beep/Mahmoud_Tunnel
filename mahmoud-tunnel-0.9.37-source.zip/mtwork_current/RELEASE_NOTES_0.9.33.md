# Mahmoud Tunnel 0.9.33 — source update

- Corrected VPN state reporting: starting libbox's command service is no longer treated as a connected VPN.
- The service reports CONNECTED only after Android successfully establishes the TUN interface in `openTun()`.
- Updated Android version metadata to 0.9.33 / versionCode 44.

## Verification status

- Source-level patch inspected.
- APK build attempted with `scripts/build-debug-apk.sh`; it stopped because Gradle 8.9 is not installed.
- No APK was generated.
- No device-level Android test or live server test was performed.
- A real, authorized server profile is still required to validate traffic routing end-to-end.
