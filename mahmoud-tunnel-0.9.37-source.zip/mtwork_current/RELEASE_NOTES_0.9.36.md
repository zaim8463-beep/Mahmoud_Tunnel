# Mahmoud Tunnel 0.9.36

## Changes
- Corrected TUN file-descriptor ownership to match the upstream sing-box Android VpnService contract: retain the established `ParcelFileDescriptor` and return its `fd` to libbox.
- Keep the descriptor alive until the sing-box service is closed, then close it during teardown.
- Android versionCode: 47.

## Why this change
The upstream `SagerNet/sing-box-for-android` VPNService implementation stores the `ParcelFileDescriptor` returned by `Builder.establish()` and returns `pfd.fd` from `openTun()`. This project now follows that lifecycle instead of detaching the descriptor and retaining a duplicate.

## Verification status
- Source-level comparison against upstream Android VPN service implementation completed.
- Shell syntax and ZIP integrity checks completed during packaging.
- Android compilation, emulator/device execution, and live server traffic remain unverified because this environment has no Android SDK/Gradle installation and cannot resolve external download hosts.
- No public server or third-party host credentials are bundled. The server deployment script requires a VPS owned or administered by the user.
