# Mahmoud Tunnel 0.9.35

## Changes
- Corrected the Android-to-native TUN file-descriptor handoff: detach the established descriptor before returning it to libbox, and retain a duplicate lifecycle handle until engine shutdown.
- Moved CONNECTED publication out of `openTun()`: it is now sent only after `startOrReloadService()` returns successfully and the TUN callback has established an interface.
- Added explicit STARTING-state handling in the Activity UI.
- Clear pending profile config if the user declines Android VPN permission.
- Android versionCode: 46.

## Verification status
- Source archive and shell syntax checks are run at packaging time.
- No APK is claimed: this environment has no Android SDK/Gradle installation and outbound DNS is unavailable.
- No real device or authorized remote VPS is available here, so tunnel traffic and server reachability remain unverified.
